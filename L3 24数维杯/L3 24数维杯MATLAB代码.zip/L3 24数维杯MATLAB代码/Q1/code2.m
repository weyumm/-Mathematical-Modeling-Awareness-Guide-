clc
clear
close all
%% 读取数据
filename = '附件1：钻井测量数据.xlsx';  
  
% 获取Excel文件中的所有工作表名称  
sheets = sheetnames(filename);  
  
% 创建一个cell数组来存储读取的矩阵数据  
data = cell(numel(sheets), 1);  
  
% 循环读取每个工作表中的数据  
for i = 1:numel(sheets)  
    data{i} = readmatrix(filename, 'Sheet', sheets{i});  
end  
%% 计算特征
f_set = []; %最终的特征表
for n=1:14 % 遍历每一个勘探点
    site = data{n};
    thick = 0; %记录厚度
    num = 0; %记录有效点数
    sum_porosity = 0; %记录总孔隙度
    sum_saturation = 0; %记录总饱和度
    flag = 0; %上一个探索点是否为油层，0则不是，非0则为该油层开始高度
    for i=1:size(site,1) % 遍历所有深度
        if site(i,2)==-9999||site(i,3)==-9999
            if flag~=0 %如果上一个是油层
                thick = thick+site(i,1)-site(flag,1);
            end
            flag=0;
            continue %如果是无效数据就直接跳过
        else
            if site(i,3)~=0 %如果是油层
                num = num+1;
                if flag==0 %如果是油层开始点
                    flag = i;
                end
                sum_porosity = sum_porosity+site(i,2); %更新总孔隙度
                sum_saturation = sum_saturation+abs(site(i,3)); %更新总饱和度
                if i==size(site,1)
                    thick = thick+site(i,1)-site(flag,1);
                end
            else
                if flag~=0 %如果上一个是油层
                    thick = thick+site(i,1)-site(flag,1);
                end
                flag=0;
            end
        end
    end
    f_set(n,1) = thick;
    f_set(n,2) = sum_porosity/num;
    f_set(n,3) = sum_saturation/num;
end

