code1.m：初步绘制分布图。
code2.m：计算各勘探点的三个特征的取值。
code3.m：克里金插值算法
code4.m：TOPSIS算法
code5.m：绘制分布范围图
