clc
clear
data = xlsread('插值后特征表.xlsx');
data = data(:,3:5);
% 2、标准化
normalized_data = mapminmax(data', 0, 1)';
% 3、计算正负距离
maxmin(1,:) = max(normalized_data); 
maxmin(2,:) = min(normalized_data); 
D_score=[];
for i=1:size(normalized_data,1)
    D_score(i,1)=sqrt((maxmin(1,1)-normalized_data(i,1)).^2+(maxmin(1,2)-normalized_data(i,2)).^2+...
        (maxmin(1,3)-normalized_data(i,3)).^2);
    D_score(i,2)=sqrt((maxmin(2,1)-normalized_data(i,1)).^2+(maxmin(2,2)-normalized_data(i,2)).^2+...
        (maxmin(2,3)-normalized_data(i,3)).^2);
end
% 4、计算得分
score=[];
for i=1:size(D_score,1)
   score(i,1)= D_score(i,2)./(D_score(i,1)+D_score(i,2));
end