clc
clear
close all

site = xlsread('附件2：井位信息.xlsx');
data = xlsread('勘探点特征表.xlsx');

x = site(:,1);
y = site(:,2);

Set = cell(1,3); %储存插值后的结果
for f = 1:size(data,2) % 遍历每个特征
    z = data(:,f);
    
    % 创建一个更密集的网格，用于插值
    [xq, yq] = meshgrid(min(x):100:max(x), min(y):100:max(y));
    
    % 使用 TriScatteredInterp 进行插值
    interp = TriScatteredInterp(x, y, z, 'linear'); % 这里可以选择不同的插值方法，比如 'linear'、'nearest'、'natural' 等
    
    % 计算插值结果
    zq = interp(xq, yq);
    
    % 去除 zq 中的 NaN 值
    nan_indices = isnan(zq); % 找到 NaN 值所在的位置
    xq_cleaned = xq(~nan_indices); % 去除对应位置的 xq 值
    yq_cleaned = yq(~nan_indices); % 去除对应位置的 yq 值
    zq_cleaned = zq(~nan_indices); % 去除对应位置的 zq 值
    
    % 将 xq_cleaned, yq_cleaned, zq_cleaned 按对应关系另存至一个 nx3 的矩阵
    data_matrix = [xq_cleaned(:), yq_cleaned(:), zq_cleaned(:)];
    Set{f} = data_matrix;
    
    figure(f)
    % 创建热力图
    pcolor(xq, yq, zq);
    shading interp; % 使用插值的颜色填充
    colormap('hot'); % 使用热色调的颜色映射
    colorbar; % 添加颜色条
    xlabel('X');
    ylabel('Y');
    
    % 将图框的背景颜色改为白色
    set(gcf, 'color', 'w');
end


