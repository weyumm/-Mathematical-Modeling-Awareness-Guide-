clc
clear
close all

data = xlsread('TOPSIS得分.xlsx');
x = data(:,1);
y = data(:,2);
z = data(:,6);


% 绘制散点图  
scatter(x, y, [], z, 'filled');  
colormap('hot'); % 使用热色调的颜色映射
colorbar; % 添加颜色条  
xlabel('X');  
ylabel('Y');
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w');