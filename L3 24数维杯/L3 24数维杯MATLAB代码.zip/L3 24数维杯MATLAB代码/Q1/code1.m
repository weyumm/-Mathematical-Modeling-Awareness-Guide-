clc
clear all
data = xlsread('附件2：井位信息.xlsx');
scatter(data(:,1),data(:,2));