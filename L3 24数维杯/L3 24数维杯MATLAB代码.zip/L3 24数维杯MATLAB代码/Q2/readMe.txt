code1.m：基于核密度估计算法计算概率分布。调用get_thick.m
code1.m：整理非线性回归数据，绘制三维散点图




get_thick.m：获取当前测点所有含油层厚度。

