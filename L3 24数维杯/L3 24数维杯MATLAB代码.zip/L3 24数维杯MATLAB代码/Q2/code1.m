clc
clear
close all
%% 读取数据
filename = '附件1：钻井测量数据.xlsx';

% 获取Excel文件中的所有工作表名称
sheets = sheetnames(filename);

% 创建一个cell数组来存储读取的矩阵数据
data = cell(numel(sheets), 1);

% 循环读取每个工作表中的数据
for i = 1:numel(sheets)
    data{i} = readmatrix(filename, 'Sheet', sheets{i});
end

%% 计算厚度概率分布
figure(1)
thick_set = []; %厚度结果表
for n=1:14 % 遍历每一个勘探点
    site = data{n};
    thick = get_thick(site);
    
    % 使用ksdensity进行核密度估计
    [f,xi] = ksdensity(thick);
    % 计算均值
    mean_saturation = trapz(xi, xi.*f);
    % 计算方差
    var_saturation = trapz(xi, (xi - mean_saturation).^2 .* f);
    % 输出均值和方差
    thick_set(n,1) = mean_saturation;
    thick_set(n,2) = var_saturation;
    % 绘制概率密度函数图
    subplot('Position',[(mod(n-1,2))/2+0.05, 1-(ceil(n/2))/7+0.04, 0.4, 1/7-0.05]);
    plot(xi,f);
    xlabelname = sprintf('W%d', n);
    xlabel(xlabelname);
    ylabel('概率密度');
end
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w')

%% 计算孔隙概率分布
figure(2)
porosity_set = []; %孔隙结果表
for n=1:14 % 遍历每一个勘探点
    site = data{n};
    porosity=[];
    for i=1:size(site,1) % 遍历所有深度
        if site(i,2)==-9999||site(i,3)==-9999
            continue %如果是无效数据就直接跳过
        else
            if site(i,3)~=0 %如果是油层
                porosity = [porosity;site(i,2)]; %更新总孔隙度
            end
        end
    end
    % 使用ksdensity进行核密度估计
    [f,xi] = ksdensity(porosity);
    % 计算均值
    mean_saturation = trapz(xi, xi.*f);
    % 计算方差
    var_saturation = trapz(xi, (xi - mean_saturation).^2 .* f);
    % 输出均值和方差
    porosity_set(n,1) = mean_saturation;
    porosity_set(n,2) = var_saturation;
    % 绘制概率密度函数图
    subplot('Position',[(mod(n-1,2))/2+0.05, 1-(ceil(n/2))/7+0.04, 0.4, 1/7-0.05]);
    plot(xi,f);
    xlabelname = sprintf('W%d', n);
    xlabel(xlabelname);
    ylabel('概率密度');
end
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w')
%% 计算饱和度概率分布
figure(3)
saturation_set = []; %总饱和度结果表
for n=1:14 % 遍历每一个勘探点
    site = data{n};
    saturation=[];
    for i=1:size(site,1) % 遍历所有深度
        if site(i,2)==-9999||site(i,3)==-9999
            continue %如果是无效数据就直接跳过
        else
            if site(i,3)~=0 %如果是油层
                saturation = [saturation;site(i,3)]; %更新总孔隙度
            end
        end
    end
    % 使用ksdensity进行核密度估计
    [f,xi] = ksdensity(saturation);
    % 计算均值
    mean_saturation = trapz(xi, xi.*f);
    % 计算方差
    var_saturation = trapz(xi, (xi - mean_saturation).^2 .* f);
    % 输出均值和方差
    saturation_set(n,1) = mean_saturation;
    saturation_set(n,2) = var_saturation;
    % 绘制概率密度函数图
    subplot('Position',[(mod(n-1,2))/2+0.05, 1-(ceil(n/2))/7+0.04, 0.4, 1/7-0.05]);
    plot(xi,f);
    xlabelname = sprintf('W%d', n);
    xlabel(xlabelname);
    ylabel('概率密度');
end
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w')