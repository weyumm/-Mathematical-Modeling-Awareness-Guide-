clc
clear
close all
site = xlsread('附件2：井位信息.xlsx');
data1 = xlsread('密度估计结果表.xlsx','厚度');
data2 = xlsread('密度估计结果表.xlsx','孔隙');
data3 = xlsread('密度估计结果表.xlsx','饱和度');

set = [site data1(:,1) data2(:,1) data3(:,1)];

% 创建一个新的图形窗口  
figure;  

% 绘制三维散点图  
scatter3(set(:,1), set(:,2), set(:,3), 50, 'b', 'o', 'filled');  
hold on;  
scatter3(set(:,1), set(:,2), set(:,4), 50, 'r', 's', 'filled');  
scatter3(set(:,1), set(:,2), set(:,5), 50, 'g', '^', 'filled');  
hold off;  
  
% 添加标题和轴标签  
xlabel('X');  
ylabel('Y');  
zlabel('均值');  
