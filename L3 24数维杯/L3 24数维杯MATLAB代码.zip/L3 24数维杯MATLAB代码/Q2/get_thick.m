function thick = get_thick(site)
thick = []; %厚度矩阵
flag = 0; %上一个探索点是否为油层，0则不是，非0则为该油层开始高度
for i=1:size(site,1) % 遍历所有深度
    if site(i,2)==-9999||site(i,3)==-9999
        if flag~=0 %如果上一个是油层
            thick = [thick;site(i,1)-site(flag,1)];
        end
        flag=0;
        continue %如果是无效数据就直接跳过
    else
        if site(i,3)~=0 %如果是油层
            if flag==0 %如果是油层开始点
                flag = i;
            end
            if i==size(site,1)
                thick = [thick;site(i,1)-site(flag,1)];
            end
        else
            if flag~=0 %如果上一个是油层
                thick = [thick;site(i,1)-site(flag,1)];
            end
            flag=0;
        end
    end
end
end