clc
clear
% 创建一个cell数组来存储读取的表格数据  
data = cell(14, 1);  
  
% 循环读取文件  
for i = 1:14  
    filename = sprintf('W%02d_Por_So.txt', i); % 生成文件名  
    data{i} = readmatrix(filename); % 读取文件并存储为矩阵 ;  
end  
% 对齐数据
for i=1:14
    if size(data{i},2)==4
        for ii=1:size(data{i},1)
            if ~isnan(data{i}(ii,4))
                data{i}(ii,2:3)=data{i}(ii,3:4);
            end
        end
        data{i}=data{i}(:,1:3);
    end
end

% 创建一个新的 Excel 文件  
filename = 'data.xlsx';  
delete(filename);  % 确保文件不存在，避免写入时出错  
for i = 1:14  
    sheetname = sprintf('Sheet%d', i);  
    writematrix(data{i}, filename, 'Sheet', sheetname);  
end  
