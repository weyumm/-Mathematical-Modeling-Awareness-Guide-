function [mued_popu]=mutation(popu_croed,PM)
new_popu=[];
popu=popu_croed;
for nind=1:size(popu,1)
    if PM>rand
        indi=popu(nind,:);
        start_index = randi([1, 4]); % 随机选择起始位置
        end_index = randi([start_index+1, 5]); % 随机选择结束位置，确保大于起始位置
        new_indi = indi; % 复制 indi 到 new_indi
        new_indi(start_index:end_index) = indi(end_index:-1:start_index); % 将指定段逆序
        new_popu=[new_popu;new_indi];
    end
end
mued_popu=[popu;new_popu];

end