function [popu]=initialization(NIND,constituency)
realm = size(constituency,1);
for nind = 1:NIND
    random_numbers = zeros(1, 5); % 创建一个数组来存储随机生成的数字
    for i = 1:5
        % 生成一个随机数
        new_number = randi(realm);
        
        % 检查新生成的随机数是否已经存在于数组中
        while ismember(new_number, random_numbers)
            new_number = randi(realm); % 如果存在，则重新生成随机数
        end
        
        random_numbers(i) = new_number; % 将新的不重复随机数存入数组中
    end
    popu(nind,:) = random_numbers;
end
end