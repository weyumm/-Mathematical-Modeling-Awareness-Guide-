function [popu]=FIX(popu,constituency)
 
num = size(constituency,1);
% 检查每行是否有重复值  
for i = 1:size(popu, 1)  
    row = popu(i, :);  
    unique_row = unique(row);  
    if length(unique_row) < length(row)  
        for j = 1:length(row)  
            while sum(row == row(j)) > 1  
                row(j) = randi([1, num]);  
            end  
        end  
        popu(i, :) = row;  
    end  
end  