function [obj]=fitness(popu,constituency,exist)
obj = zeros(size(popu,1),2);
for i=1:size(popu,1)
    new_site = [];
    for j=1:size(popu,2)
        new_site(j,:) = constituency(popu(i,j),1:2);
    end
    % 计算欧氏距离
    distances = zeros(size(new_site, 1), size(exist, 1));
    for ii = 1:size(new_site, 1)
        for j = 1:size(exist, 1)
            distances(ii, j) = sqrt(sum((new_site(ii, :) - exist(j, :)).^2));
        end
    end
    
    % 计算所有欧氏距离的方差（目标1）
    obj(i,1) = var(distances(:));
    
    for j=1:size(popu,2)
        obj(i,2) = obj(i,2)+constituency(popu(i,j),3);
    end
end
end