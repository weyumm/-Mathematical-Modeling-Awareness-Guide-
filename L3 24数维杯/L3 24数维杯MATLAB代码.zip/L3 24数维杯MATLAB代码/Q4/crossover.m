function [croed_popu]=crossover(popu,PC)
new_popu=[];
for nind=1:size(popu,1)/2
    if PC>rand %如果要交叉
        indi1=popu(nind*2-1,:);
        indi2=popu(nind*2,:);
        swap_positions = randperm(5, 2); % 从 1 到 I 中随机选择2个不重复的位置
        new_indi1 = indi1;
        new_indi2 = indi2;
        for i = 1:size(swap_positions,2)
            temp = new_indi1(swap_positions(i));
            new_indi1(swap_positions(i)) = new_indi2(swap_positions(i));
            new_indi2(swap_positions(i)) = temp;
        end
        new_popu=[new_popu;new_indi1;new_indi2];
    end
end
croed_popu=[popu;new_popu];
