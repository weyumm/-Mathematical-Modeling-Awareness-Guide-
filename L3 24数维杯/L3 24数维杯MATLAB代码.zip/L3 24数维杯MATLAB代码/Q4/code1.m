clc
clear
close all
data = xlsread('资源区表.xlsx');
exist = xlsread('附件2：井位信息.xlsx');
%% 求出解空间
% 创建一个空矩阵来存储筛选后的数据  
constituency = [];  
% 逐行检查data中的每一行是否存在于exist中  
for i = 1:size(data, 1)  
    row = data(i, :);  
    % 检查是否存在于exist中  
    if ~ismember(row(1:2), exist, 'rows')  
        % 如果某一行不存在于exist中，则将其添加到filtered_data中  
        constituency = [constituency; row];  
    end  
end 
%% 定义参数
ITER=1000;
PC=0.7;
PM=0.3;
NIND=50;
%% 初始化
[popu]=initialization(NIND,constituency);
[obj]=fitness(popu,constituency,exist);
in_obj = obj;
obj_record=mean(obj);
%% 进入循环
for iter=1:ITER
    [croed_popu]=crossover(popu,PC);
    [croed_popu]=FIX(croed_popu,constituency);
    [mued_popu]=mutation(croed_popu,PM);
    [obj]=fitness(mued_popu,constituency,exist);
    [popu,obj]=selection(mued_popu,obj,NIND);
    obj_record=[obj_record;mean(obj)];
end
[f_obj]=fitness(popu,constituency,exist);
%% 出图
% 收敛曲线
figure;  
% 绘制第一列的收敛曲线  
subplot(2, 1, 1);  
plot(obj_record(:, 1), 'b', 'LineWidth', 2);  
xlabel('Iterations');  
ylabel('距离方差平均适应度');  
grid on;  
  
% 绘制第二列的收敛曲线  
subplot(2, 1, 2);  
plot(obj_record(:, 2), 'r', 'LineWidth', 2);  
xlabel('Iterations');  
ylabel('新探点价值平均适应度');  
grid on;  
  
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w');


% 帕累托图 
figure;  
scatter(f_obj(:,1), f_obj(:,2), 'filled', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'b');  
hold on
scatter(in_obj(:,1), in_obj(:,2), 'filled', 'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'r');  
% 添加标题和标签  
xlabel('距离方差');  
ylabel('新探点价值');  
  
% 添加网格线  
grid on;  

%% 获取点
SET(1,:) = constituency(1297,:);
SET(2,:) = constituency(1298,:);
SET(3,:) = constituency(1252,:);
SET(4,:) = constituency(1205,:);
SET(5,:) = constituency(1343,:);