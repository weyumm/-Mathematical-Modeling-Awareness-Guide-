clc
clear
close all
data = xlsread('各网点天然气水合物资源含量.xlsx');

% 使用ksdensity进行核密度估计
[f,xi] = ksdensity(data(:,3));

% 绘制概率密度函数图
plot(xi,f);
xlabel('各网点天然气水合物资源含量');
ylabel('概率密度');
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w')
