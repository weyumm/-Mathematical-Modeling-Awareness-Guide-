clc
clear
close all
data1 = xlsread('聚类结果表.xlsx');
data2 = xlsread('考虑地理位置聚类结果表.xlsx');
data = [data1(:,[2,3,4]) data2(:,5)];
Set = zeros(7,4);
for i=1:size(data,1)
    k = data(i,4);
    Set(k,1:3) = Set(k,1:3) + data(i,1:3); %记录数据
    Set(k,4) = Set(k,4)+1; %记录有几个
end
Set(:,1:3) = Set(:,1:3)./Set(:,4);
v = zeros(7,1);
for i=1:size(Set,1)
    v(i,1) = (10000*Set(i,4)).*Set(i,1).*Set(i,2).*Set(i,3).*155;
end
V = sum(v);