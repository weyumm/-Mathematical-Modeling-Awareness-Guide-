clc
clear
close all
data = xlsread('插值后特征表.xlsx');
Set = data(:,1:2);
Set(:,3) = 10000.*data(:,3).*data(:,4).*data(:,5).*155;

x = Set(:,1);
y = Set(:,2);
z = Set(:,3);


% 绘制散点图  
scatter(x, y, [], z, 'filled');  
colormap('hot'); % 使用热色调的颜色映射
colorbar; % 添加颜色条  
xlabel('X');  
ylabel('Y');
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w');