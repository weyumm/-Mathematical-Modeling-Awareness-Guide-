clc
clear
close all

data = xlsread('聚类结果表.xlsx');
data = data(:,[1,2,6,7]);
  
% 提取数据  
x = data(:, 1);  
y = data(:, 2);  
z = data(:, 3);  
category = data(:, 4);  
  
% 获取分类号的唯一值  
categories = unique(category);  
  
% 设置颜色映射  
colors = parula(length(categories));  
  
% 创建新的三维图  

for i = 1:length(categories)  
    indices = (category == categories(i));  
    scatter3(x(indices), y(indices), z(indices), 50, colors(i, :), 'filled');  
    hold on
end  

% 添加标签和标题  
xlabel('X');  
ylabel('Y');  
zlabel('得分');  
 
  
% 添加图例  
legend(cellstr(num2str(categories)), 'Location', 'best');    
% 将图框的背景颜色改为白色
set(gcf, 'color', 'w');