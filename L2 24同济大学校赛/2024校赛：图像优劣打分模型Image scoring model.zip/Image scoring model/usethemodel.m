% 读取图片并进行边缘补全
imgPath = '.\图片3.png';
img = imread(imgPath);
imgSize = size(img);
padHeight = 32 - mod(imgSize(1), 32);
padWidth = 32 - mod(imgSize(2), 32);
imgPadded = padarray(img, [padHeight padWidth], 'replicate', 'post');

% 初始化图像块存储
numBlocksX = size(imgPadded, 2) / 32;
numBlocksY = size(imgPadded, 1) / 32;
imgBlocks = zeros(32, 32, 3, numBlocksX*numBlocksY, 'like', imgPadded);

% 分割图像为32x32的块
count = 1;
for i = 1:numBlocksY
    for j = 1:numBlocksX
        imgBlocks(:, :, :, count) = imgPadded((i-1)*32+1:i*32, (j-1)*32+1:j*32, :);
        count = count + 1;
    end
end

% 准备 ImageDatastore
imds = augmentedImageDatastore([32 32 3], imgBlocks);

% 加载模型
modelPath = '.\Image_scoring_model.mat';
load(modelPath, 'net');

% 使用模型对每个图像块进行分类
predictedLabels = classify(net, imds);

% 计算得分和映射等级
scores = arrayfun(@(x) scoreMapping(char(x)), predictedLabels);
levels = ["差", "中", "良", "优"];
levelMappings = levels(double(predictedLabels));

% 输出每个图像块的得分和等级
% for i = 1:numel(predictedLabels)
    % fprintf('Block %d: Score: %f, Level: %s\n', i, scores(i), levelMappings(i));
% end

% 计算得分的汇总
averageScore = mean(scores);
totalScore = sum(scores);

% 输出得分的汇总
fprintf('图片打分: %.2f\n', averageScore);
% fprintf('Total Score: %.2f\n', totalScore);

% 将分类数组转换为双精度数组
predictedLabelsDouble = double(predictedLabels);

% 计算每个类别的频率
totalCount = numel(predictedLabelsDouble);
probability = zeros(1, length(levels));
for i = 1:length(levels)
    probability(i) = sum(predictedLabelsDouble == i) / totalCount;
end

% 绘制横向条形统计图
barh(levels, probability, 'FaceColor', 'flat', 'LineWidth', 1.5, 'EdgeColor', 'black');
xlabel('概率');
ylabel('等级');
title('图像块等级概率分布');
grid on;

% 显示平均得分
text(1.5, probability(1) + 0.1 * max(probability), ['平均得分: ', num2str(averageScore, '%.2f')], 'FontSize', 12);


% 定义一个简单的分数映射函数
function score = scoreMapping(label)
    % 将类标签转换为分数
    switch label
        case '1'
            score = 90; % 优
        case '2'
            score = 75; % 良
        case '3'
            score = 60; % 中
        case '4'
            score = 45; % 差
        otherwise
            score = 0;  % 未知类别
    end
end

