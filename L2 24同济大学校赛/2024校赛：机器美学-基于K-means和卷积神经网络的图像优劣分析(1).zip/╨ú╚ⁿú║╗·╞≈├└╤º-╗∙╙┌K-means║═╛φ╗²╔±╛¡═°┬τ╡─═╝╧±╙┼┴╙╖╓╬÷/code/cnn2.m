opts = detectImportOptions('D:\高行周的资料\大一下\校赛\模型构建\cnn.xlsx');
labelsTable = readtable('D:\高行周的资料\大一下\校赛\模型构建\cnn.xlsx', opts);

% 打印数据表labelsTable的列名，以便确认图片名称和类别所在的列
disp(labelsTable.Properties.VariableNames);

% 假设图片名称在第一列，并将其赋值给变量imageNameColumn
imageNameColumn = labelsTable.Properties.VariableNames{1};

% 假设类别标签在第四列，并将其赋值给变量categoryColumn
categoryColumn = labelsTable.Properties.VariableNames{4};

% 将labelsTable中的类别列转换为分类变量（categorical）
labels = categorical(labelsTable.(categoryColumn));

% 图片文件路径
imageFolder = "D:\高行周的资料\大一下\校赛\tid2013\distorted_images";

% 在processed_names列的每个文件名后添加'.bmp'扩展名
labelsTable.processed_names = strcat(labelsTable.processed_names, '.bmp');

% 创建imageDatastore对象
imds = imageDatastore(imageFolder, 'Labels', labels, 'ReadFcn', @(x)imresize(imread(x), [512 384]));

% 定义CNN模型
layers = [
    imageInputLayer([512 384 3]) % 输入层，接受尺寸为512x384像素、3个通道（例如RGB颜色通道）的图像
    convolution2dLayer(5, 20, 'Padding', 'same') % 卷积层，使用5x5的卷积核，生成20个特征图，使用相同填充保持输出尺寸不变
    batchNormalizationLayer % 批量归一化层，用于提高训练稳定性和收敛速度
    reluLayer %ReLU激活层，引入非线性，使得网络可以学习更复杂的特征
    maxPooling2dLayer(2, 'Stride', 2) % 最大池化层，使用2x2的池化窗口，步长为2，减少空间维度
    fullyConnectedLayer(4) % 全连接层，输出4个节点，对应于4个类别
    softmaxLayer % Softmax层，将全连接层的输出转换为概率分布
    classificationLayer]; % 分类层，用于计算损失函数和性能指标


% 配置训练选项
options = trainingOptions('sgdm', ...
    'MiniBatchSize', 10, ...             % 每一批次（mini-batch）的大小设置为10
    'MaxEpochs', 10, ...                 % 训练的最大轮数（epoch）设置为10
    'InitialLearnRate', 1e-3, ...        % 初始学习率设置为0.001
    'Shuffle', 'every-epoch', ...        % 每个epoch之前打乱数据顺序
    'ValidationData', imds, ...          % 验证数据集，用于评估模型性能
    'ValidationFrequency', 10, ...       % 每训练10个批次进行一次验证
    'Verbose', true, ...                 % 在命令行窗口显示训练进度
    'Plots', 'training-progress', ...    % 在训练过程中显示进度图
    'CheckpointPath', 'D:\高行周的资料\大一下\校赛\模型构建\cnnresults', ... % 设置检查点保存路径
    'ExecutionEnvironment', 'gpu');      % 指定使用GPU进行训练



% 训练模型
net = trainNetwork(imds, layers, options);

% 保存最终模型
save('D:\高行周的资料\大一下\校赛\模型构建\cnnresults\finalModel.mat', 'net');