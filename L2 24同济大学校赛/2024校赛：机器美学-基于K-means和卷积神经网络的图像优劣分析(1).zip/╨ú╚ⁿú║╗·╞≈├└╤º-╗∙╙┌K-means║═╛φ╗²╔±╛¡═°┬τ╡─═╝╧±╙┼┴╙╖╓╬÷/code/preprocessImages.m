function preprocessImages()
    % 定义源文件和目标存储位置
    srcFolder = '.\cnntest';
    destFile = '.\code\preprocessedData.mat';
    
    % 加载标签
    opts = detectImportOptions('.\cnntest.xlsx');
    labelsTable = readtable('=.\cnntest.xlsx', opts);
    imageNames = labelsTable.(labelsTable.Properties.VariableNames{1});
    labels = categorical(labelsTable.(labelsTable.Properties.VariableNames{4}));

    % 初始化块和标签数组
    imageBlocks = [];
    blockLabels = categorical([]);
    blockCount = 0;
    
    % 遍历每个图像
    for i = 1:length(imageNames)
        imagePath = fullfile(srcFolder, [imageNames{i} '.bmp']);
        img = imread(imagePath);
        img = imresize(img, [512 512]); % 确保图片足够大
        % 切割图像并保存块
        for row = 0:31:480
            for col = 0:31:480
                block = img(row+1:row+32, col+1:col+32, :);
                blockCount = blockCount + 1;
                if isempty(imageBlocks)
                    imageBlocks = zeros(32, 32, 3, numel(imageNames) * 192, 'uint8');
                end
                imageBlocks(:,:,:,blockCount) = block;
                blockLabels(end+1) = labels(i);
            end
        end
    end
    
    % 保存处理后的数据
    save(destFile, 'imageBlocks', 'blockLabels');
end

