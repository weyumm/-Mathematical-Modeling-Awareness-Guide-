import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 读取Excel文件
file_path = r"D:\高行周的资料\大一下\校赛\模型构建\data.xlsx"
df = pd.read_excel(file_path)

# 选择第2-8列进行归一化
scaler = MinMaxScaler()
df.iloc[:, 1:8] = scaler.fit_transform(df.iloc[:, 1:8])

# 将归一化后的数据写入新的Excel文件
output_path = r"D:\高行周的资料\大一下\校赛\模型构建\data_std.xlsx"
df.to_excel(output_path, index=False)

print("归一化处理完成，文件已保存至:", output_path)
