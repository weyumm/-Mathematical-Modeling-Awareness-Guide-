import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale, StandardScaler
import matplotlib.pyplot as plt

# 载入数据
data = pd.read_excel(r"D:\高行周的资料\大一下\校赛\模型构建\topsis_score_withnames.xlsx")

# 选取需要处理的数据列
scores = data.iloc[:, 1].values.reshape(-1, 1)

# 使用StandardScaler进行标准化，以便我们可以逆向转换
scaler = StandardScaler()
scores_scaled = scaler.fit_transform(scores)

# 使用KMeans算法进行聚类分析
kmeans = KMeans(n_clusters=4, random_state=0).fit(scores_scaled)

# 将聚类结果添加到原始数据DataFrame中
data['class_results'] = kmeans.labels_

# 确定每个聚类的中心值并计算分类界限
centers = kmeans.cluster_centers_.squeeze()
sorted_centers = sorted(centers)

# 计算分类界限值
boundaries = [(sorted_centers[i] + sorted_centers[i + 1]) / 2 for i in range(len(sorted_centers) - 1)]

# 可视化聚类结果
plt.figure(figsize=(10, 6))
colors = ['red','orange',  'yellow', 'green'] # 按照要求的颜色顺序

# 分配颜色和标签到对应的聚类
cluster_labels = sorted(range(len(centers)), key=lambda x: centers[x])
color_dict = {cluster_labels[i]: colors[i] for i in range(4)}

for i in range(4):
    plt.scatter(data[data['class_results'] == i].index, scores[data['class_results'] == i], c=color_dict[i])

plt.xlabel('Index')
plt.ylabel('Score')
plt.title('Cluster Visualization')
plt.legend()
plt.show()

# 逆向转换界限值到原始尺度
original_boundaries = scaler.inverse_transform([[x] for x in boundaries]).squeeze()

# 输出原始尺度上的分类界限值
print("Cluster boundaries (on original scale):", original_boundaries)
