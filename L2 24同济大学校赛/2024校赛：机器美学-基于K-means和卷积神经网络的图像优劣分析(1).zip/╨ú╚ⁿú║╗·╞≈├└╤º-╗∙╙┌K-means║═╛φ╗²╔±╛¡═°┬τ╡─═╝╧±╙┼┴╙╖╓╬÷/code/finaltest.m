% 加载预处理后的数据
load('.\code\preprocessedData.mat');

% 创建 ImageDatastore
imds = augmentedImageDatastore([32 32 3], imageBlocks, blockLabels);

% 定义 CNN 模型
layers = [
    imageInputLayer([32 32 3])
    convolution2dLayer(3, 16, 'Padding', 'same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    convolution2dLayer(3, 32, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    fullyConnectedLayer(100)
    dropoutLayer(0.5)
    fullyConnectedLayer(numel(categories(blockLabels)))
    softmaxLayer
    classificationLayer];

% 配置训练选项
options = trainingOptions('sgdm', ...
    'MiniBatchSize', 128, ...
    'MaxEpochs', 60, ...
    'InitialLearnRate', 1e-3, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', imds, ...          % 验证数据集，用于评估模型性能
    'ValidationFrequency', 100, ...       % 每训练 个批次进行一次验证
    'Verbose', true, ...
    'Plots', 'training-progress');

% 设置定时器来每5分钟保存一次模型
checkpointDir = '.\code\checkpoints';
if ~exist(checkpointDir, 'dir')
    mkdir(checkpointDir);
end

t = timer;
t.StartDelay = 300;  % 300 seconds = 5 minutes
t.TimerFcn = @(myTimerObj, thisEvent) saveModel(net, checkpointDir);
t.Period = 300;  % Repeat interval
t.ExecutionMode = 'fixedRate';

% 开始定时器
start(t);

% 训练模型
net = trainNetwork(imds, layers, options);

% 停止并删除定时器
stop(t);
delete(t);

% 定义保存模型的函数
function saveModel(net, checkpointDir)
    timestamp = datestr(now, 'yyyy-mm-dd-HH-MM-SS');
    filename = fullfile(checkpointDir, ['netCheckpoint-' timestamp '.mat']);
    save(filename, 'net', '-v7.3');  % Use '-v7.3' for potentially large models
    disp(['Model saved at ' timestamp]);
end
