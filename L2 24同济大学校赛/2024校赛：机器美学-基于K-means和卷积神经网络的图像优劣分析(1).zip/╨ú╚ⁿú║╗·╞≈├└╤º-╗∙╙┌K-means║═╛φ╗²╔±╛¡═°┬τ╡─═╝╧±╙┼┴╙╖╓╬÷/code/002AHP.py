import numpy as np
import pandas as pd
from scipy.linalg import eigh

# Define the decision matrix provided by the user
decision_matrix = np.array([
    [1, 1/2, 1/2, 1/3, 1/2, 1, 1/4],
    [2, 1, 1/3, 1/2, 1/3, 2, 1/3],
    [2, 3, 1, 1/4, 1, 1/2, 1/5],
    [3, 2, 4, 1, 4, 3, 1/2],
    [2, 3, 1, 1/4, 1, 1/2, 1/5],
    [1, 1/2, 2, 1/3, 2, 1, 1/4],
    [4, 3, 5, 2, 5, 4, 1]
])

# Normalize the decision matrix
def normalize_matrix(matrix):
    return matrix / matrix.sum(axis=1, keepdims=True)

# Normalize the decision matrix
normalized_matrix = normalize_matrix(decision_matrix)

# Calculate the eigenvalues and eigenvectors
eigenvalues, eigenvectors = eigh(normalized_matrix, eigvals=(7-1, 7-1))

# Get the principal eigenvector (corresponding to the largest eigenvalue)
principal_eigenvector = eigenvectors[:, 0]

# Normalize the principal eigenvector to get the weights
weights = principal_eigenvector / principal_eigenvector.sum()

# Create a DataFrame to display the results
weight_df = pd.DataFrame({'Parameter': ['FSIM', 'FSIMc', 'MSSIM', 'PSNRHA', 'SSIM', 'WSNR', 'MOS'], 'Weight': weights})
weight_df

"""
AHP结果
FSIM: 0.171075
FSIMc: 0.175965
MSSIM: 0.170652
PSNRHA: 0.084523
SSIM: 0.158257
WSNR: 0.126549
MOS: 0.112979
"""