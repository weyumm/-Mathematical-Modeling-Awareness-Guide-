import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
import matplotlib.pyplot as plt

# 载入数据
data = pd.read_excel(r"D:\高行周的资料\大一下\校赛\模型构建\topsis_score_withnames.xlsx")

# 确保我们正在处理的数据是正确的列
scores = data.iloc[:, 1].values.reshape(-1, 1)

# 对数据进行标准化处理
scores_scaled = scale(scores)

# 使用KMeans算法进行聚类分析
kmeans = KMeans(n_clusters=4, random_state=0).fit(scores_scaled)

# 将聚类结果添加到原始数据DataFrame中
data['class_results'] = kmeans.labels_

# 可视化聚类结果
plt.figure(figsize=(10, 6))
colors = ['r', 'y', 'b', 'g']
for i in range(4):
    plt.scatter(data[data['class_results'] == i].index, scores[data['class_results'] == i], c=colors[i])

plt.xlabel('Index')
plt.ylabel('Score')
plt.title('Cluster Visualization')
plt.legend()
plt.show()

# 输出结果到Excel文件
data.to_excel(r"D:\高行周的资料\大一下\校赛\模型构建\classresults.xlsx", index=False)

print("聚类完成，结果已输出到Excel文件，并进行了可视化。")
