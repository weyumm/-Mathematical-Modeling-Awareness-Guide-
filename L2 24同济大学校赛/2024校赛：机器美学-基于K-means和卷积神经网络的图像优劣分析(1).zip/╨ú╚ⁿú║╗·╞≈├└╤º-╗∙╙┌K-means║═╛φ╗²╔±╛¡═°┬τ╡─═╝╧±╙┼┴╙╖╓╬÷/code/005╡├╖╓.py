import pandas as pd

# 加载Excel文件
file_path = r".\code\score.xlsx"
data = pd.read_excel(file_path)

# 定义权重
weights = {
    "FSIM": 0.1360174,
    "FSIMc": 0.1261054,
    "MSSIM": 0.1130804,
    "PSNRHA": 0.0901946,
    "SSIM": 0.110115,
    "WSNR": 0.26835939999999997,
    "MOS": 0.15612779999999998
}

# 计算综合分数
data["compositescore"] = data.apply(lambda row: sum(row[1:8] * [weights[col] for col in data.columns[1:8]]), axis=1)

# 输出Excel文件
output_file_path = r".\code\score.xlsx"
data.to_excel(output_file_path, index=False)

output_file_path
