import pandas as pd

# 读取Excel文件
file_path = "D:\\高行周的资料\\大一下\\校赛\\模型构建\\classresults.xlsx"
df = pd.read_excel(file_path)

# 创建一个新的列“point”来存储转换后的结果
df['point'] = df.iloc[:, 3].map({0: 2, 1: 4, 2: 1, 3: 3})

# 输出新的Excel文件
output_file_path = "D:\\高行周的资料\\大一下\\校赛\\模型构建\\class1234.xlsx"
df.to_excel(output_file_path, index=False)

print("文件已成功处理并保存为 'class1234.xlsx'")
