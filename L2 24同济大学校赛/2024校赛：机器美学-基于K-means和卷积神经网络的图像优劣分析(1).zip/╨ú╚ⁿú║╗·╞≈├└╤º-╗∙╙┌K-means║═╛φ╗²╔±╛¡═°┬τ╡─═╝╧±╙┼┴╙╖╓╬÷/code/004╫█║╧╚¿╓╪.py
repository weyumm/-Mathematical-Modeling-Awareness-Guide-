# AHP和CRIDIT的权重
ahp_weights = {
    "FSIM": 0.171075,
    "FSIMc": 0.175965,
    "MSSIM": 0.170652,
    "PSNRHA": 0.084523,
    "SSIM": 0.158257,
    "WSNR": 0.126549,
    "MOS": 0.112979
}

cridit_weights = {
    "FSIM": 0.083431,
    "FSIMc": 0.051316,
    "MSSIM": 0.026723,
    "PSNRHA": 0.098702,
    "SSIM": 0.037902,
    "WSNR": 0.481075,
    "MOS": 0.220851
}

# AHP和CRIDIT的权重分配
ahp_weight = 0.6
cridit_weight = 0.4

# 计算综合权重
for metric in ahp_weights:
    ahp_weights[metric] *= ahp_weight
for metric in cridit_weights:
    cridit_weights[metric] *= cridit_weight

# 打印两个权重合成的综合权重
for metric in ahp_weights:
    print(f"{metric}: {ahp_weights[metric] + cridit_weights[metric]}")

"""
综合权重结果
FSIM: 0.1360174
FSIMc: 0.1261054
MSSIM: 0.1130804
PSNRHA: 0.0901946
SSIM: 0.110115
WSNR: 0.26835939999999997
MOS: 0.15612779999999998
"""