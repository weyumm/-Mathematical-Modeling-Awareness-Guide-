% 请确保你有Deep Learning Toolbox
clc;
clear;
close all;

% 图片文件夹和Excel文件路径
imageFolder = 'D:\高行周的资料\大一下\校赛\模型构建\cnntest';
excelFile = 'D:\高行周的资料\大一下\校赛\模型构建\cnntest.xlsx';

% 读取图片类别
data = readtable(excelFile);
classNames = unique(data.point); % 获取唯一的类别标签
classLabels = categorical(data.point);

% 创建图像数据存储器
imds = imageDatastore(imageFolder, 'Labels', classLabels, 'IncludeSubfolders', true, 'FileExtensions', '.bmp', 'LabelSource', 'none');

% 指定每张图片的正确大小
inputSize = [384 512 3];  % 注意这里改为了正确的尺寸

% 定义CNN结构
layers = [
    imageInputLayer(inputSize)
    convolution2dLayer(3,8,'Padding','same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)
    convolution2dLayer(3,16,'Padding','same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    fullyConnectedLayer(length(classNames))
    softmaxLayer
    classificationLayer
];

% 设置使用GPU的训练选项
options = trainingOptions('sgdm', ...
    'InitialLearnRate',0.01, ...
    'MaxEpochs',10, ...
    'MiniBatchSize',10, ...
    'Shuffle','every-epoch', ...
    'Verbose',true, ...
    'Plots','training-progress', ...
    'CheckpointPath','D:\高行周的资料\大一下\校赛\模型构建\cnntestresults', ...
    'ExecutionEnvironment','gpu'); % 指定使用GPU

% 训练模型
net = trainNetwork(imds,layers,options);

