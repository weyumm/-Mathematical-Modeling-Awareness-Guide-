import os
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.callbacks import ModelCheckpoint
from PIL import Image

# 图片和Excel文件的路径
dataset_path = "D:\\高行周的资料\\大一下\\校赛\\模型构建\\cnntest"
excel_path = "D:\\高行周的资料\\大一下\\校赛\\模型构建\\cnntest.xlsx"
output_path = "D:\\高行周的资料\\大一下\\校赛\\模型构建\\cnntestresults"

# 读取Excel文件，获取图片标签
labels_df = pd.read_excel(excel_path)
labels = labels_df.iloc[:, 3].values

# 加载图片数据和对应标签
def load_images_and_labels(dataset_path, labels):
    images = []
    for filename in sorted(os.listdir(dataset_path)):
        img_path = os.path.join(dataset_path, filename)
        img = Image.open(img_path).resize((512, 384))
        img = np.array(img)
        images.append(img)
    return np.array(images), np.array(labels)

images, labels = load_images_and_labels(dataset_path, labels)

# 创建数据生成器
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

# 构建CNN模型
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(384, 512, 3)),
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Flatten(),
    Dense(512, activation='relu'),
    Dropout(0.5),
    Dense(4, activation='softmax')  # 假设有4个类别
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# 模型保存的回调函数
checkpoint_callback = ModelCheckpoint(
    os.path.join(output_path, 'model_epoch_{epoch:02d}.h5'), 
    period=10, 
    save_weights_only=False,
    save_best_only=False
)

# 训练模型
model.fit(
    datagen.flow(images, labels, subset='training'), 
    validation_data=datagen.flow(images, labels, subset='validation'), 
    epochs=20, 
    callbacks=[checkpoint_callback]
)
