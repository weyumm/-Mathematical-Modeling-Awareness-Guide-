
% 加载标签
opts = detectImportOptions('D:\高行周的资料\大一下\校赛\模型构建\cnn.xlsx');
labelsTable = readtable('D:\高行周的资料\大一下\校赛\模型构建\cnn.xlsx', opts);

% 检查列名并选择正确的列
disp(labelsTable.Properties.VariableNames); % 打印列名，确保我们选择正确的列
imageNameColumn = labelsTable.Properties.VariableNames{1}; % 假设图片名称在第一列
categoryColumn = labelsTable.Properties.VariableNames{4}; % 假设类别在第四列

labels = categorical(labelsTable.(categoryColumn));  % 将类别转换为分类变量

% 图片文件路径
imageFolder = "D:\高行周的资料\大一下\校赛\tid2013\distorted_images";
imds = imageDatastore(imageFolder, 'FileExtensions', '.bmp', 'Labels', labels, 'ReadFcn', @(x)imresize(imread(x), [512 384]));

% 接下来的代码（定义CNN模型和训练设置）保持不变


% 定义CNN模型
layers = [
    imageInputLayer([512 384 3])
    convolution2dLayer(5, 20, 'Padding', 'same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    fullyConnectedLayer(4)
    softmaxLayer
    classificationLayer];

% 配置训练选项
options = trainingOptions('sgdm', ...
    'MiniBatchSize', 10, ...             % 每一批次（mini-batch）的大小设置为10
    'MaxEpochs', 10, ...                 % 训练的最大轮数（epoch）设置为10
    'InitialLearnRate', 1e-3, ...        % 初始学习率设置为0.001
    'Shuffle', 'every-epoch', ...        % 每个epoch之前打乱数据顺序
    'ValidationData', imds, ...          % 验证数据集，用于评估模型性能
    'ValidationFrequency', 30, ...       % 每训练10个批次进行一次验证
    'Verbose', true, ...                 % 在命令行窗口显示训练进度
    'Plots', 'training-progress', ...    % 在训练过程中显示进度图
    'CheckpointPath', 'D:\高行周的资料\大一下\校赛\模型构建\cnnresults', ... % 设置检查点保存路径
    'ExecutionEnvironment', 'gpu');      % 指定使用GPU进行训练


% 训练模型
net = trainNetwork(imds, layers, options);

% 保存最终模型
save('D:\高行周的资料\大一下\校赛\模型构建\cnnresults\finalModel.mat', 'net');