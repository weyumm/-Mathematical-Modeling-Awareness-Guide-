% 加载模型
modelPath = 'D:\高行周的资料\大一下\校赛\模型构建\cnntestresults\finalModel.mat';
load(modelPath, 'net');

% 定义图像输入尺寸
inputSize = [512 384];  % 根据你的网络调整

% 创建imageDatastore来读取文件夹下的所有图片
folderPath = 'D:\高行周的资料\大一下\校赛\模型构建\photo';
imds = imageDatastore(folderPath, ...
    'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames', ...
    'ReadFcn', @(x)imresize(imread(x), inputSize));

% 预测并显示结果
results = struct();
for i = 1:numel(imds.Files)
    img = readimage(imds, i);
    predictedLabel = classify(net, img);
    results(i).FileName = imds.Files{i};
    results(i).PredictedLabel = char(predictedLabel);
    fprintf('File: %s, Predicted Label: %s\n', imds.Files{i}, char(predictedLabel));
end

