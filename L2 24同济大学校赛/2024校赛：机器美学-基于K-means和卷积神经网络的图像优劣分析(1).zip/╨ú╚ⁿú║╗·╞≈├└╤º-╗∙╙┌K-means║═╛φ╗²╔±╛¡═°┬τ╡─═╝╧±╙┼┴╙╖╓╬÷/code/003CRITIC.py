import pandas as pd

# Load the Excel file
file_path = './data_std.xlsx'
data = pd.read_excel(file_path)

# Display the first few rows of the dataframe
data.head()

import numpy as np

# Define a function to standardize the data
def standardize(data):
    return (data - data.mean(axis=0)) / data.std(axis=0)

# Standardize the parameters (columns 1 to 7)
std_data = standardize(data.iloc[:, 1:8])

# Define a function to calculate entropy
def entropy(column):
    # Normalize the column so that it sums to 1 (as a probability distribution)
    prob = column / column.sum()
    # Avoid 0 values which can cause problems in the log
    prob = prob.replace(0, np.finfo(float).eps)
    # Calculate the entropy
    return -np.sum(prob * np.log2(prob))

# Calculate entropy for each parameter
entropies = std_data.apply(entropy, axis=0)

# Define a function to calculate the weight of each parameter
def calculate_weights(entropies):
    # Inverse of entropy gives the weight, normalized by dividing by the sum
    weights = (1 - entropies) / (len(entropies) - np.sum(entropies))
    return weights

# Calculate the weights for each parameter
weights = calculate_weights(entropies)

# Create a DataFrame to display the results
weight_df = pd.DataFrame({'Parameter': std_data.columns, 'Weight': weights})
weight_df

"""
CRIDIT结果
FSIM: 0.083431
FSIMc: 0.051316
MSSIM: 0.026723
PSNRHA: 0.098702
SSIM: 0.037902
WSNR: 0.481075
MOS: 0.220851
"""
