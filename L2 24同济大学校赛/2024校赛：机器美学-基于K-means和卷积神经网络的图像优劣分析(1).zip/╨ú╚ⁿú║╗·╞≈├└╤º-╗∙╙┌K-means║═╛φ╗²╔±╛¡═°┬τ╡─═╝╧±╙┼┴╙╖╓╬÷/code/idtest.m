% 获取imds中的文件名和标签
fileNames = imds.Files;
imdsLabels = imds.Labels;

% 初始化一个用于存储不匹配信息的数组
mismatchInfo = [];

% 遍历文件名，检查标签是否一致
for i = 1:length(fileNames)
    % 获取当前文件名（不含路径）
    currentFileName = fullfile(imageFolder, fileNames{i}.name);
    
    % 在labelsTable中查找对应的行
    row = findstrcmp(labelsTable.(imageNameColumn), currentFileName);
    
    % 如果找到了对应的行，检查标签是否一致
    if ~isempty(row)
        if ~isequal(imdsLabels(i), labelsTable.(categoryColumn)(row))
            % 如果标签不一致，则将信息存储到mismatchInfo中
            mismatchInfo(end+1, 1) = currentFileName;
            mismatchInfo(end, 2) = imdsLabels(i);
            mismatchInfo(end, 3) = labelsTable.(categoryColumn)(row);
        end
    else
        % 如果在labelsTable中没有找到对应的文件名，则将信息存储到mismatchInfo中
        mismatchInfo(end+1, 1) = currentFileName;
        mismatchInfo(end, 2) = imdsLabels(i);
        mismatchInfo(end, 3) = '未找到';
    end
end

% 如果mismatchInfo非空，则打印不匹配信息
if ~isempty(mismatchInfo)
    disp('存在标签不匹配的图片：');
    disp(mismatchInfo);
else
    disp('所有图片的标签都匹配。');
end

