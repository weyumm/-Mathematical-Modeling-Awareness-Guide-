import pandas as pd
import numpy as np

# 权重
weights = {
    'FSIM': 0.1360174,
    'FSIMc': 0.1261054,
    'MSSIM': 0.1130804,
    'PSNRHA': 0.0901946,
    'SSIM': 0.110115,
    'WSNR': 0.26835939999999997,
    'MOS': 0.15612779999999998
}

# 读取Excel文件
df = pd.read_excel(r".\code\score.xlsx")

# 选择第2-8列数据
data = df.iloc[:, 1:8]

# 归一化数据
normalized_data = data.copy()
for column in data.columns:
    normalized_data[column] = data[column] / np.sqrt((data[column] ** 2).sum())

# 加权规范化的决策矩阵
weighted_normalized_data = normalized_data.copy()
for column in normalized_data.columns:
    weighted_normalized_data[column] = normalized_data[column] * weights[column]

# 确定正理想解和负理想解
positive_ideal_solution = weighted_normalized_data.max()
negative_ideal_solution = weighted_normalized_data.min()

# 计算每个方案与正理想解和负理想解的距离
distance_to_positive_ideal = np.sqrt(((weighted_normalized_data - positive_ideal_solution) ** 2).sum(axis=1))
distance_to_negative_ideal = np.sqrt(((weighted_normalized_data - negative_ideal_solution) ** 2).sum(axis=1))

# 计算TOPSIS得分
topsis_score = distance_to_negative_ideal / (distance_to_positive_ideal + distance_to_negative_ideal)

# 将TOPSIS得分添加到原始DataFrame中
df['TOPSISSCORE'] = topsis_score

# 输出结果到Excel文件
df.to_excel(r".\code\score.xlsx", index=False)

print("TOPSIS得分已计算并保存到Excel文件。")
