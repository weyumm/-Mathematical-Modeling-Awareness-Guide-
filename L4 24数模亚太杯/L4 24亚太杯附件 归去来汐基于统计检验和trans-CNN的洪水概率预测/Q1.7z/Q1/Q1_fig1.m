clc;clear;close all;

% 加载洪水数据
load('train.mat');

% 删除数据矩阵的第一列（ID）
data(:,1) = [];

% 初始化存储相关系数的矩阵
rho_spearman = zeros(20, 20);
rho_pearson = zeros(20, 20);

% 计算斯皮尔曼和皮尔逊相关系数矩阵
for i = 1:20
    for j = i:20 % 只计算上三角
        rho_spearman(i, j) = corr(data(:, i), data(:, j), 'Type', 'Spearman');
        rho_spearman(j, i) = rho_spearman(i, j); % 利用对称性
        rho_pearson(i, j) = corr(data(:, i), data(:, j), 'Type', 'Pearson');
        rho_pearson(j, i) = rho_pearson(i, j); % 利用对称性
    end
end

% 可视化斯皮尔曼相关系数矩阵
figure;
subplot(1, 2, 1);
heatmap(rho_spearman);
title('斯皮尔曼秩相关系数矩阵');
xlabel('指标');
ylabel('指标');
colormap(jet);

% 可视化皮尔逊相关系数矩阵
subplot(1, 2, 2);
heatmap(rho_pearson);
title('皮尔逊相关系数矩阵');
xlabel('指标');
ylabel('指标');
colormap(jet);

% 显示相关系数矩阵
disp('斯皮尔曼秩相关系数矩阵:');
disp(rho_spearman);
disp('皮尔逊相关系数矩阵:');
disp(rho_pearson);

% 提取斯皮尔曼秩相关系数的p值
p_values_spearman = rho_spearman(2:end, 1); % 斯皮尔曼秩相关系数的p值位于第二行到最后一行的第一列

% 提取皮尔逊相关系数的p值
p_values_pearson = rho_pearson(2:end, 1); % 皮尔逊相关系数的p值位于第二行到最后一行的第一列

% 显示p值
disp('斯皮尔曼秩相关系数的p值:');
disp(p_values_spearman);
disp('皮尔逊相关系数的p值:');
disp(p_values_pearson);