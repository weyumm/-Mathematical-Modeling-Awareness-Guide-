% 读取CSV文件
data = readtable('correlation_matrix.csv', 'ReadRowNames', true, 'VariableNamingRule', 'preserve');

% 提取相关系数矩阵和列名
correlation_matrix = table2array(data);
column_names = data.Properties.VariableNames;

% 绘制热力图
figure;
imagesc(correlation_matrix);
colorbar;
title('指标与洪水概率的相关热力图');
set(gca, 'XTick', 1:length(column_names), 'XTickLabel', column_names, 'XTickLabelRotation', 45);
set(gca, 'YTick', 1:length(column_names), 'YTickLabel', data.Properties.RowNames);

% 设置颜色映射
colormap('cool');
caxis([-1, 1]); % 设置颜色条范围为[-1, 1]
