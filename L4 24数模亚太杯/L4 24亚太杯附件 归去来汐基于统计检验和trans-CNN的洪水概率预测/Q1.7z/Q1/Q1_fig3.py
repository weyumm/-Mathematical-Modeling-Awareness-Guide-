import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import scipy.stats as stats

# 假设data是一个包含所有特征数据的DataFrame

# 定义每行和每列的子图数量
n_features = len(features)
n_rows = 2 * (n_features // 4) + 2 * int(n_features % 4 > 0)  # 确保有足够的行来容纳所有子图
n_cols = 4  # 每行4列

# 创建一个图形对象
plt.figure(figsize=(n_cols * 5, n_rows * 4))  # 根据子图数量调整图形大小

# 绘制每个特征的直方图和Q-Q图
for i, feature in enumerate(features):
    plt.subplot(n_rows, n_cols, 2*i+1)  # 直方图的子图位置
    sns.histplot(data[feature], kde=True)
    plt.title(f'{feature} 直方图')

    plt.subplot(n_rows, n_cols, 2*i+2)  # Q-Q图的子图位置
    stats.probplot(data[feature], dist="norm", plot=plt)
    plt.title(f'{feature} Q-Q图')

# 调整子图之间的间距
plt.subplots_adjust(
    left=0.05,   # 左侧边距
    right=0.95,  # 右侧边距
    top=0.95,    # 顶部边距
    bottom=0.05, # 底部边距
    wspace=0.4,  # 列之间的间距
    hspace=0.6   # 行之间的间距
)

# 显示图形
plt.show()