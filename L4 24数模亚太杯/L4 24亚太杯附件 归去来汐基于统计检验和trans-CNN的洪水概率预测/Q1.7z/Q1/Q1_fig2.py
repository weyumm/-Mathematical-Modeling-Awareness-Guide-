# 对数变换
data['对数变换的洪水概率'] = np.log1p(data['洪水概率'])

# 重新计算Jarque-Bera检验
jb_test_stat, jb_p_value = stats.jarque_bera(data['对数变换的洪水概率'])
print('对数变换后的洪水概率 JB Statistic:', jb_test_stat, 'p-value:', jb_p_value)

# 可视化对数变换后的数据
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
sns.histplot(data['对数变换的洪水概率'], kde=True)
plt.title('对数变换后的洪水概率 直方图')

plt.subplot(1, 2, 2)
stats.probplot(data['对数变换的洪水概率'], dist="norm", plot=plt)
plt.title('对数变换后的洪水概率 Q-Q 图')

plt.tight_layout()
plt.show()