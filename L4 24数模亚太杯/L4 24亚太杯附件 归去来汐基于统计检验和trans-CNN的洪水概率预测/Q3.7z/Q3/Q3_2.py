﻿import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from lightgbm import LGBMRegressor
import joblib
import matplotlib.pyplot as plt
from scipy.stats import norm

# 读取数据
file_path = 'train_pre.csv'
data = pd.read_csv(file_path)

# 确保列名与数据中的实际列名一致
data.columns = [
    'id', '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素', '洪水概率'
]

# 定义特征和目标列
features = [
    '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素'
]
target = '洪水概率'

# 数据抽样和划分训练集和测试集
sample_data = data.sample(frac=0.1, random_state=42)  # 从完整数据中抽样，比例为10%，随机种子为42
X = sample_data[features]  # 特征变量
y = sample_data[target]    # 目标变量

# 数据标准化和归一化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, shuffle=True)

# 定义LightGBM参数
params = {
    'max_depth': 5,          # 树的最大深度
    'n_estimators': 100,     # 森林中树的数量
    'random_state': 42       # 随机种子，用于复现结果
}

# 初始化LightGBM回归模型
clf = LGBMRegressor(**params)

# 执行交叉验证并获取交叉验证预测值
cv_pred = cross_val_predict(clf, X_train, y_train, cv=5)

# 训练模型
clf.fit(X_train, y_train, eval_set=[(X_test, y_test)], eval_metric='mse')
# 注：eval_set指定验证集，用于模型在训练过程中的验证；eval_metric设置为均方误差（mse）

# 保存训练好的模型
joblib.dump(clf, 'lightgbm_model.pkl')
print("Final model saved.")

# 模型预测和评估
y_pred = clf.predict(X_test)  # 对测试集进行预测

# 定义计算评估指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred, squared=False)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    def mean_absolute_percentage_error(y_true, y_pred):
        y_true, y_pred = np.array(y_true), np.array(y_pred)
        return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    mape = mean_absolute_percentage_error(y_true, y_pred)
    
    return mse, rmse, mae, r2, mape

# 计算训练集的评估指标
train_mse, train_rmse, train_mae, train_r2, train_mape = calculate_metrics(y_train, clf.predict(X_train))

# 计算交叉验证集的评估指标
cv_mse, cv_rmse, cv_mae, cv_r2, cv_mape = calculate_metrics(y_train, cv_pred)

# 计算测试集的评估指标
test_mse, test_rmse, test_mae, test_r2, test_mape = calculate_metrics(y_test, y_pred)

# 打印训练集的评估指标
print("Training Set Metrics:")
print(f"  MSE: {train_mse}")
print(f"  RMSE: {train_rmse}")
print(f"  MAE: {train_mae}")
print(f"  R² Score: {train_r2}")
print(f"  MAPE: {train_mape:.2f}%")

# 打印交叉验证集的评估指标
print("\nCross Validation Set Metrics:")
print(f"  MSE: {cv_mse}")
print(f"  RMSE: {cv_rmse}")
print(f"  MAE: {cv_mae}")
print(f"  R² Score: {cv_r2}")
print(f"  MAPE: {cv_mape:.2f}%")

# 打印测试集的评估指标
print("\nTest Set Metrics:")
print(f"  MSE: {test_mse}")
print(f"  RMSE: {test_rmse}")
print(f"  MAE: {test_mae}")
print(f"  R² Score: {test_r2}")
print(f"  MAPE: {test_mape:.2f}%")

# 可视化预测结果分布的直方图和CDF折线图
plt.figure(figsize=(12, 6))

# 绘制直方图
plt.subplot(1, 2, 1)
plt.hist(y_pred, bins=500, color='lightblue', edgecolor='lightblue', density=True)
plt.title('Distribution of Predicted Values')
plt.xlabel('Predicted Values')
plt.ylabel('Density')
plt.grid(True)

# 绘制正态分布曲线
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, np.mean(y_pred), np.std(y_pred))
plt.plot(x, p, 'r', linewidth=2)

# 绘制CDF折线图
plt.subplot(1, 2, 2)
sorted_idx = np.argsort(y_pred)
plt.plot(y_pred[sorted_idx], np.linspace(0, 1, len(y_pred), endpoint=False)[sorted_idx], color='orange', label='CDF')
plt.title('CDF of Predicted Values')
plt.xlabel('Predicted Values')
plt.ylabel('Cumulative Probability')
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.show()

# 打印交叉验证的均方误差
print(f"\nCross Validation Mean Squared Error (MSE): {np.mean(-cv_scores)}")
