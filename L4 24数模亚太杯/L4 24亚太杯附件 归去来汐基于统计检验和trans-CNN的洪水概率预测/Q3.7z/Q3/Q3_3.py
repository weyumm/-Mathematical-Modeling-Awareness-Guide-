﻿import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from lightgbm import LGBMRegressor
import matplotlib.pyplot as plt

# 读取数据
file_path = 'train_pre.csv'
data = pd.read_csv(file_path)

# 确保列名与数据中的实际列名一致
data.columns = [
    'id', '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素', '洪水概率'
]

# 定义特征和目标列
features = [
    '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素'
]
target = '洪水概率'

# 数据抽样和划分训练集和测试集
sample_data = data.sample(frac=0.1, random_state=42)  # 从完整数据中抽样，比例为10%，随机种子为42
X = sample_data[features]  # 特征变量
y = sample_data[target]    # 目标变量

# 数据标准化和归一化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, shuffle=True)

# 定义LightGBM参数
params = {
    'max_depth': 5,          # 树的最大深度
    'n_estimators': 100,     # 森林中树的数量
    'random_state': 42       # 随机种子，用于复现结果
}

# 初始化LightGBM回归模型
clf = LGBMRegressor(**params)

# 训练模型
clf.fit(X_train, y_train)

# 获取基于增益的特征重要性
feature_importance_gain = clf.booster_.feature_importance(importance_type='gain')

# 获取基于分裂的特征重要性
feature_importance_split = clf.booster_.feature_importance(importance_type='split')

# 计算加权参考重要性
weighted_feature_importance = 0.8 * feature_importance_gain + 0.2 * feature_importance_split

# 构建特征重要性的DataFrame并排序
df_importance = pd.DataFrame({
    'Feature': features,
    'Gain Importance': feature_importance_gain,
    'Split Importance': feature_importance_split,
    'Weighted Importance': weighted_feature_importance
})

# 按加权参考重要性降序排列
df_importance = df_importance.sort_values(by='Weighted Importance', ascending=False)

# 打印前20个特征的重要性指标
print("Top 20 Feature Importance:")
print(df_importance.head(20))