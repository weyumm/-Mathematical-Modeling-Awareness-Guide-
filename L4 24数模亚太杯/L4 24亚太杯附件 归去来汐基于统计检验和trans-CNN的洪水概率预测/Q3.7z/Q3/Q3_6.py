import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import time
import os

# 自定义数据集类
class FloodDataset(Dataset):
    def __init__(self, file_path):
        self.data = pd.read_excel(file_path)
        self.features = self.data.iloc[:, :-1].values
        self.targets = self.data.iloc[:, -1].values

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, idx):
        sample = torch.tensor(self.features[idx], dtype=torch.float32)
        target = torch.tensor(self.targets[idx], dtype=torch.float32)
        return sample, target

class SimplifiedCNNTransformerModel(nn.Module):
    def __init__(self):
        super(SimplifiedCNNTransformerModel, self).__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(1, 8, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(2),
            nn.Conv1d(8, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        self.transformer_layer = nn.TransformerEncoderLayer(d_model=16, nhead=4)
        self.transformer = nn.TransformerEncoder(self.transformer_layer, num_layers=2)
        self.fc = nn.Sequential(
            nn.Linear(16, 8),
            nn.ReLU(),
            nn.Linear(8, 1)
        )

    def forward(self, x):
        x = x.unsqueeze(1)  # 增加通道维度
        x = self.cnn(x)
        x = x.permute(2, 0, 1)  # 转换维度以适应Transformer输入
        x = self.transformer(x)
        x = x.mean(dim=0)
        x = self.fc(x)
        return x

# 计算评估指标
def calculate_metrics(outputs, targets):
    outputs = outputs.detach().cpu().numpy()
    targets = targets.detach().cpu().numpy()
    mse = np.mean((outputs - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(outputs - targets))
    mape = np.mean(np.abs((targets - outputs) / targets)) * 100
    ss_res = np.sum((targets - outputs) ** 2)
    ss_tot = np.sum((targets - np.mean(targets)) ** 2)
    r2 = 1 - (ss_res / ss_tot)
    return mse, rmse, mae, mape, r2

# 验证函数
def validate_model(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    running_metrics = np.zeros(5)  # 用于累积评估指标
    with torch.no_grad():
        for inputs, targets in dataloader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.squeeze(), targets)
            running_loss += loss.item()
            metrics = calculate_metrics(outputs.squeeze(), targets)
            running_metrics += np.array(metrics)
    avg_loss = running_loss / len(dataloader)
    avg_metrics = running_metrics / len(dataloader)
    return avg_loss, avg_metrics

# 保存模型函数
def save_model(model, optimizer, epoch, filepath):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
    }, filepath)

# 加载模型函数
def load_model(model, optimizer, filepath):
    checkpoint = torch.load(filepath)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['epoch']

# 训练函数
def train_model(model, train_loader, val_loader, criterion, optimizer, num_epochs, log_file, device, model_path=None):
    start_epoch = 0
    if model_path and os.path.exists(model_path):
        start_epoch = load_model(model, optimizer, model_path)
        print(f"Loaded model from {model_path}, starting from epoch {start_epoch + 1}")

    model.to(device)
    start_time = time.time()
    last_save_time = start_time
    save_interval = 300  
    epoch_save_interval = 50  # 每个50epoch保存一次模型
    os.makedirs(os.path.dirname(log_file), exist_ok=True)  # 确保目录存在

    with open(log_file, 'a') as f:
        for epoch in range(start_epoch, num_epochs):
            model.train()
            running_loss = 0.0
            running_metrics = np.zeros(5)  # 用于累积评估指标
            for i, (inputs, targets) in enumerate(train_loader):
                inputs, targets = inputs.to(device), targets.to(device)
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs.squeeze(), targets)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()
                metrics = calculate_metrics(outputs.squeeze(), targets)
                running_metrics += np.array(metrics)

            # 训练集平均损失和评估指标
            avg_loss = running_loss / len(train_loader)
            avg_metrics = running_metrics / len(train_loader)
            elapsed_time = time.time() - start_time

            # 验证集平均损失和评估指标
            val_loss, val_metrics = validate_model(model, val_loader, criterion, device)

            log = (f"Epoch [{epoch+1}/{num_epochs}], Train Loss: {avg_loss:.6f}, "
                   f"Train MSE: {avg_metrics[0]:.6f}, Train RMSE: {avg_metrics[1]:.6f}, "
                   f"Train MAE: {avg_metrics[2]:.6f}, Train MAPE: {avg_metrics[3]:.2f}, Train R2: {avg_metrics[4]:.6f}, "
                   f"Val Loss: {val_loss:.6f}, Val MSE: {val_metrics[0]:.6f}, Val RMSE: {val_metrics[1]:.6f}, "
                   f"Val MAE: {val_metrics[2]:.6f}, Val MAPE: {val_metrics[3]:.2f}, Val R2: {val_metrics[4]:.6f}, "
                   f"Time Elapsed: {elapsed_time:.2f}s")
            print(log)
            f.write(log + '\n')

            # 检查是否需要保存模型
            current_time = time.time()
            if (epoch + 1) % epoch_save_interval == 0 or (current_time - last_save_time) >= save_interval:
                save_model(model, optimizer, epoch, f"model_epoch_{epoch+1}.pth")
                last_save_time = current_time

# 加载数据
train_file_path = r"train_5.xlsx"
val_file_path = r"test_5.xlsx"
train_dataset = FloodDataset(train_file_path)
val_dataset = FloodDataset(val_file_path)
train_loader = DataLoader(train_dataset, batch_size=9182, shuffle=True)  # 增大batch size以增加显存占用
val_loader = DataLoader(val_dataset, batch_size=9182, shuffle=False)

# 初始化模型、损失函数和优化器
model = SimplifiedCNNTransformerModel()
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 检查是否有GPU
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 训练模型
num_epochs = 200
log_file = r"train.txt"


model_path = r"model_epoch_000.pth"
train_model(model, train_loader, val_loader, criterion, optimizer, num_epochs, log_file, device, model_path)
