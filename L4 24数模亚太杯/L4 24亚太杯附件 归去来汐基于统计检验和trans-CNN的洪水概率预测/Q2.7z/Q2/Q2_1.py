
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 读取数据
data = pd.read_excel(r'D:\高行周的资料\大二上\亚太杯\Bcode\Q2\train_flood_probability.xlsx')

# 提取洪水概率列
flood_probabilities = data['洪水概率'].values.reshape(-1, 1)

# 执行K-means聚类，聚为三类
kmeans = KMeans(n_clusters=3, random_state=0).fit(flood_probabilities)
labels = kmeans.labels_
centers = kmeans.cluster_centers_

# 按照聚类中心从大到小排序
sorted_centers = np.sort(centers, axis=0)[::-1]
sorted_labels = np.argsort(-centers, axis=0).flatten()
label_mapping = {i: sorted_labels[i] for i in range(len(sorted_labels))}
sorted_labels = np.array([label_mapping[label] for label in labels])

# 统计每个类别的数据点数量
high_risk_size = np.sum(sorted_labels == 0)
medium_risk_size = np.sum(sorted_labels == 1)
low_risk_size = np.sum(sorted_labels == 2)

# 获取每个类别的聚类中心
high_risk_center = sorted_centers[0]
medium_risk_center = sorted_centers[1]
low_risk_center = sorted_centers[2]

# 输出结果
print('高风险等级：')
print('聚类中心：约 {:.6f}'.format(high_risk_center[0]))
print('包含的数据点数量：{}'.format(high_risk_size))
print('中风险等级：')
print('聚类中心：约 {:.6}'.format(medium_risk_center[0]))
print('包含的数据点数量：{}'.format(medium_risk_size))
print('低风险等级：')
print('聚类中心：约 {:.6f}'.format(low_risk_center[0]))
print('包含的数据点数量：{}'.format(low_risk_size))
#保证中文正常显示
plt.rcParams['font.sans-serif'] = ['SimHei']
# 设置字体大小
plt.rcParams['font.size'] = 18
# 可视化聚类结果（箱线图）
plt.figure(figsize=(10, 6))
sns.boxplot(x=sorted_labels, y=flood_probabilities.flatten(), palette='viridis')
plt.xticks([0, 1, 2], ['高风险', '中风险', '低风险'])
plt.title('K-means 聚类结果')
plt.xlabel('风险等级')
plt.ylabel('洪水概率')
plt.show()


