﻿import pandas as pd
import scipy.stats as stats

# 假设data是包含所有数据的DataFrame，包括洪水概率和其他指标
file_path = 'train_pre.csv'
data = pd.read_csv(file_path)

# 重新命名列名，确保列名符合你的数据格式
data.columns = [
    'id', '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素', '洪水概率'
]

# 根据洪水风险等级分组的数据
high_risk_data = data[data['洪水概率'] >= 0.568]
medium_risk_data = data[(data['洪水概率'] >= 0.507) & (data['洪水概率'] < 0.568)]
low_risk_data = data[data['洪水概率'] < 0.507]

# Define the features to be tested
features = [
    '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
    '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
    '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
    '湿地损失', '规划不足', '政策因素'
]

# Initialize a dictionary to store the Mann-Whitney U test results
mwu_results = {}

# Perform Mann-Whitney U test for each feature
for feature in features:
    # Perform Mann-Whitney U test between high risk and medium risk groups
    mwu_statistic_high_medium, mwu_p_value_high_medium = stats.mannwhitneyu(high_risk_data[feature], medium_risk_data[feature], alternative='two-sided')
    
    # Perform Mann-Whitney U test between high risk and low risk groups
    mwu_statistic_high_low, mwu_p_value_high_low = stats.mannwhitneyu(high_risk_data[feature], low_risk_data[feature], alternative='two-sided')
    
    # Perform Mann-Whitney U test between medium risk and low risk groups
    mwu_statistic_medium_low, mwu_p_value_medium_low = stats.mannwhitneyu(medium_risk_data[feature], low_risk_data[feature], alternative='two-sided')
    
    # Store the results in the dictionary
    mwu_results[feature] = {
        'High vs Medium': {'MWU Statistic': mwu_statistic_high_medium, 'p-value': mwu_p_value_high_medium},
        'High vs Low': {'MWU Statistic': mwu_statistic_high_low, 'p-value': mwu_p_value_high_low},
        'Medium vs Low': {'MWU Statistic': mwu_statistic_medium_low, 'p-value': mwu_p_value_medium_low}
    }

# Display the results
for feature, results in mwu_results.items():
    print(f"Feature: {feature}")
    print(f"High vs Medium Risk: MWU Statistic = {results['High vs Medium']['MWU Statistic']}, p-value = {results['High vs Medium']['p-value']}")
    print(f"High vs Low Risk: MWU Statistic = {results['High vs Low']['MWU Statistic']}, p-value = {results['High vs Low']['p-value']}")
    print(f"Medium vs Low Risk: MWU Statistic = {results['Medium vs Low']['MWU Statistic']}, p-value = {results['Medium vs Low']['p-value']}")
    print("")