﻿import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns
import logging

# 设置日志记录
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 读取数据函数，包含异常处理
def load_data(file_path):
    try:
        data = pd.read_csv(file_path)
        logger.info(f"成功读取数据文件: {file_path}")
        return data
    except FileNotFoundError:
        logger.error(f"文件未找到: {file_path}")
        raise
    except Exception as e:
        logger.error(f"读取数据文件出错: {str(e)}")
        raise

# KMeans聚类分析函数，包含异常处理
def kmeans_clustering(data, features, n_clusters=3):
    try:
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(data[features])

        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        data['风险类别'] = kmeans.fit_predict(scaled_data)

        # 分析聚类中心
        cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
        cluster_centers_df = pd.DataFrame(cluster_centers, columns=features)
        cluster_centers_df['风险类别'] = [f'类别{i+1}' for i in range(n_clusters)]

        return data, cluster_centers_df, scaled_data

    except ValueError as ve:
        logger.error(f"聚类分析出错: {str(ve)}")
        raise
    except Exception as e:
        logger.error(f"处理数据时出现未知错误: {str(e)}")
        raise

# 绘制雷达图函数，用于展示聚类中心特征
def plot_radar_chart(df, features, title):
    num_vars = len(features)
    angles = np.linspace(0, 2*np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]
    
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    
    color_palette = sns.color_palette("Set2", n_colors=len(df))
    
    for i, row in enumerate(df.iterrows()):
        values = row[1][features].values.flatten().tolist()
        values += values[:1]
        ax.plot(angles, values, linewidth=2, linestyle='solid', marker='o', markersize=8, label=row[1]['风险类别'], color=color_palette[i])
        ax.fill(angles, values, alpha=0.25, color=color_palette[i])
        
    ax.set_yticklabels([])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(features)
    
    plt.title(title, size=15, color='black', y=1.1)
    plt.legend(loc='upper right', bbox_to_anchor=(1.1, 1.1))
    plt.show()

# 绘制重要性分析图函数
def plot_importance_analysis(features, importance):
    importance_df = pd.DataFrame({'Feature': features, 'Importance': importance})
    importance_df = importance_df.sort_values(by='Importance', ascending=False)

    plt.figure(figsize=(10, 8))
    sns.barplot(x='Importance', y='Feature', data=importance_df, palette='viridis')
    plt.title('不同指标的重要性')
    plt.show()

# 灵敏度分析函数，用于评估特征对聚类结果的影响
def sensitivity_analysis(model, X, feature_names):
    try:
        base_prediction = model.predict(X)
        sensitivities = {}
        
        for i, feature in enumerate(feature_names):
            X_perturbed = X.copy()
            X_perturbed[:, i] += 0.1 * np.std(X[:, i])  # Slight perturbation
            perturbed_prediction = model.predict(X_perturbed)
            sensitivity = np.mean(np.abs(perturbed_prediction - base_prediction))
            sensitivities[feature] = sensitivity
            
        sensitivity_df = pd.DataFrame.from_dict(sensitivities, orient='index', columns=['Sensitivity'])
        sensitivity_df = sensitivity_df.sort_values(by='Sensitivity', ascending=False)
        
        return sensitivity_df
    
    except ValueError as ve:
        logger.error(f"灵敏度分析出错: {str(ve)}")
        raise
    except Exception as e:
        logger.error(f"处理数据时出现未知错误: {str(e)}")
        raise

if __name__ == "__main__":
    file_path = 'train_pre.csv'
    features = [
        '季风强度', '地形排水', '河流管理', '森林砍伐', '城市化',
        '气候变化', '大坝质量', '淤积', '农业实践', '侵蚀', '无效防灾',
        '排水系统', '海岸脆弱性', '滑坡', '流域', '基础设施恶化', '人口得分',
        '湿地损失', '规划不足', '政策因素'
    ]

    try:
        # 读取数据
        data = load_data(file_path)

        # KMeans聚类分析
        clustered_data, cluster_centers_df, scaled_data = kmeans_clustering(data, features)

        # 绘制雷达图显示聚类中心特征
        plot_radar_chart(cluster_centers_df, features, '不同风险类别的指标特征')

        # 计算并绘制重要性分析图
        pca = PCA(n_components=1)
        pca.fit(scaled_data)
        importance = np.abs(pca.components_[0])
        plot_importance_analysis(features, importance)

        # 灵敏度分析
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(clustered_data[features])
        kmeans_model = KMeans(n_clusters=3, random_state=42).fit(scaled_data)
        sensitivity_df = sensitivity_analysis(kmeans_model, scaled_data, features)

        # 绘制灵敏度分析图
        plt.figure(figsize=(10, 8))
        sns.barplot(x='Sensitivity', y=sensitivity_df.index, data=sensitivity_df)
        plt.title('不同指标的敏感性分析')    
        plt.show()

        # 绘制箱线图展示特征的鲁棒性分析结果
        plt.figure(figsize=(12, 8))
        sns.boxplot(data=scaled_data)
        plt.title('特征的鲁棒性分析')
        plt.xticks(rotation=45)
        plt.xlabel('特征', fontsize=12)
        plt.xticks(range(len(features)), features)  # 设置特征名称作为标签
        plt.show()

    except Exception as e:
        logger.error(f"程序运行出现错误: {str(e)}")
