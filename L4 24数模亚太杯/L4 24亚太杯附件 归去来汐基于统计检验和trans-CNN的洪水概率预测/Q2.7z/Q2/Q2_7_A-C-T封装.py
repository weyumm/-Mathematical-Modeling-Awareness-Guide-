﻿#AHP-CRITIC-TOPSIS+可视化封装
import pandas as pd
import numpy as np
from scipy.linalg import eigh
import matplotlib.pyplot as plt

# 模块1：AHP权重计算
def calculate_ahp_weights(excel_file, sheet_name):
    # 从Excel读取数据
    df = pd.read_excel(excel_file, sheet_name=sheet_name, index_col=0)

    # 定义归一化函数
    def normalize_matrix(matrix):
        return matrix / matrix.sum(axis=1, keepdims=True)

    # 归一化决策矩阵
    decision_matrix = df.values
    normalized_matrix = normalize_matrix(decision_matrix)

    # 计算特征值和特征向量
    eigenvalues, eigenvectors = eigh(normalized_matrix, eigvals=(normalized_matrix.shape[0]-1, normalized_matrix.shape[0]-1))
    principal_eigenvector = eigenvectors[:, 0]

    # 归一化主特征向量以获取权重
    weights = principal_eigenvector / principal_eigenvector.sum()

    return df.index, weights

# 模块2：CRITIC权重计算
def calculate_critic_weights(file_path):
    data = pd.read_csv(file_path)
    
    # 定义一个函数来标准化数据
    def standardize(data):
        return (data - data.mean(axis=0)) / data.std(axis=0)

    std_data = standardize(data.iloc[:, 1:])

    # 计算每个指标的 CRITIC 权重
    variances = std_data.var(axis=0)
    weights = 1 / variances
    weights = weights / weights.sum()

    return std_data.columns, weights

# 模块3：混合权重计算
def calculate_mixed_weights(ahp_weights, critic_weights, ahp_weight=0.6, critic_weight=0.4):
    mixed_weights = {}
    for metric in ahp_weights:
        mixed_weights[metric] = ahp_weights[metric] * ahp_weight + critic_weights[metric] * critic_weight

    return mixed_weights

# 模块4：TOPSIS评分计算
def calculate_topsis_scores(file_path, weights):
    # 读取数据并设置列名
    data = pd.read_csv(file_path, index_col=0)
    data.drop(columns=['洪水概率'], inplace=True)

    # 数据归一化到 [0, 1]
    normalized_data = data.copy()
    for column in data.columns:
        normalized_data[column] = (data[column] - data[column].min()) / (data[column].max() - data[column].min())

    # 加权规范化的决策矩阵
    weighted_normalized_data = normalized_data.copy()
    for column in normalized_data.columns:
        weighted_normalized_data[column] = normalized_data[column] * weights[column]

    # 确定正理想解和负理想解
    positive_ideal_solution = weighted_normalized_data.max()
    negative_ideal_solution = weighted_normalized_data.min()

    # 计算每个方案与正理想解和负理想解的距离
    distance_to_positive_ideal = np.sqrt(((weighted_normalized_data - positive_ideal_solution) ** 2).sum(axis=1))
    distance_to_negative_ideal = np.sqrt(((weighted_normalized_data - negative_ideal_solution) ** 2).sum(axis=1))

    # 计算TOPSIS得分
    topsis_score = distance_to_negative_ideal / (distance_to_positive_ideal + distance_to_negative_ideal)

    # 将TOPSIS得分添加到原始DataFrame中
    data['TOPSISSCORE'] = topsis_score

    # 打印部分TOPSIS得分
    print("部分TOPSIS得分：")
    print(data['TOPSISSCORE'].head())

    # 保存完整TOPSIS得分结果到CSV文件
    topsis_score_file = './topsis_score.csv'
    data.to_csv(topsis_score_file, index=True, encoding='utf-8')
    print(f"完整TOPSIS得分结果已保存至 {topsis_score_file}")

    return data

# 模块5：可视化TOPSIS得分分布
def visualize_topsis_scores(topsis_scores):
    plt.figure(figsize=(10, 6))
    plt.hist(topsis_scores, bins=500, density=True, alpha=0.7, color='b', edgecolor='b')
    plt.title('Distribution of AHP-CRITIC-TOPSIS Scores')
    plt.xlabel('Score')
    plt.ylabel('Probability Density')
    plt.grid(True)
    plt.show()

# 主程序
def main():
    # 模块1：AHP权重计算
    excel_file = 'decision_matrix.xlsx'
    sheet_name = 'Sheet1'
    ahp_metrics, ahp_weights = calculate_ahp_weights(excel_file, sheet_name)

    # 模块2：CRITIC权重计算
    file_path = 'train_pre.csv'
    critic_metrics, critic_weights = calculate_critic_weights(file_path)

    # 模块3：混合权重计算
    mixed_weights = calculate_mixed_weights(dict(zip(ahp_metrics, ahp_weights)), dict(zip(critic_metrics, critic_weights)))

    # 模块4：TOPSIS评分计算并保存结果
    topsis_scores = calculate_topsis_scores(file_path, mixed_weights)

    # 模块5：可视化TOPSIS得分分布
    visualize_topsis_scores(topsis_scores['TOPSISSCORE'])

if __name__ == "__main__":
    main()
