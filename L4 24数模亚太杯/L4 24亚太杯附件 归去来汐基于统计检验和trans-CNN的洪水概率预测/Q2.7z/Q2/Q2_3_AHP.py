﻿import pandas as pd
import numpy as np
from scipy.linalg import eigh

# 1. 从Excel读取数据
excel_file = 'decision_matrix.xlsx'
sheet_name = 'Sheet1'  # 根据实际情况修改表格名

# 读取Excel表格数据到DataFrame
df = pd.read_excel(excel_file, sheet_name=sheet_name, index_col=0)

# 2. 数据预处理：将DataFrame转换为numpy数组并归一化
decision_matrix = df.values

# 定义归一化函数
def normalize_matrix(matrix):
    return matrix / matrix.sum(axis=1, keepdims=True)

# 归一化决策矩阵
normalized_matrix = normalize_matrix(decision_matrix)

# 3. 使用AHP计算权重
# 计算特征值和特征向量
eigenvalues, eigenvectors = eigh(normalized_matrix, eigvals=(normalized_matrix.shape[0]-1, normalized_matrix.shape[0]-1))

# 获取主特征向量（对应最大特征值）
principal_eigenvector = eigenvectors[:, 0]

# 归一化主特征向量以获取权重
weights = principal_eigenvector / principal_eigenvector.sum()

# 4. 一致性检查（可选）
# 计算一致性指标 CI 和 CR
n = normalized_matrix.shape[0]
CI = (eigenvalues[0] - n) / (n - 1)

# 随机一致性指数 RI，n=20时的随机一致性指数
RI = np.array([0, 0, 0.58, 0.9, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49, 1.51, 1.52, 1.54, 1.56, 1.57, 1.59, 1.6, 1.61, 1.62, 1.63])

if n <= len(RI):
    CR = CI / RI[n-1]
else:
    print(f"随机一致性指数 (RI) 数组长度不足，无法计算一致性比率 (CR)。需要至少 {n} 个随机一致性指数。")

# 输出一致性检查结果
if CR < 0.1:
    print("一致性比率 (CR) = {:.4f}。一致性检查通过。".format(CR))
else:
    print("一致性比率 (CR) = {:.4f}。一致性检查未通过。".format(CR))

# 5. 显示权重结果
# 创建DataFrame显示结果
weight_df = pd.DataFrame({'参数': df.index, '权重': weights})
print(weight_df)