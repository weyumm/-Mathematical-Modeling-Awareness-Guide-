﻿import pandas as pd
import numpy as np

# 1. 从CSV文件中读取数据
file_path = 'train_pre.csv'
data = pd.read_csv(file_path)

# 2. 定义一个函数来标准化数据
def standardize(data):
    return (data - data.mean(axis=0)) / data.std(axis=0)

# 3. 标准化数据的指标（假设这些指标是数据的列名）
std_data = standardize(data.iloc[:, 1:])  # 假设第一列是索引或标签，从第二列开始是要处理的数据

# 4. 定义一个函数来计算 CRITIC 权重
def calculate_critic_weights(data):
    # 计算每个指标的方差
    variances = data.var(axis=0)
    # 计算每个指标的 CRITIC 权重
    weights = 1 / variances
    # 标准化权重
    weights = weights / weights.sum()
    return weights

# 5. 计算每个指标的 CRITIC 权重
weights = calculate_critic_weights(std_data)

# 6. 创建一个 DataFrame 来显示结果
weight_df = pd.DataFrame({'指标': std_data.columns, '权重': weights})
weight_df.sort_values(by='权重', ascending=False, inplace=True)  # 按权重降序排列

# 7. 打印权重结果
print(weight_df)

# 8. 输出结果到文件
output_file = 'critic_weights.csv'
weight_df.to_csv(output_file, index=False, encoding='utf-8')