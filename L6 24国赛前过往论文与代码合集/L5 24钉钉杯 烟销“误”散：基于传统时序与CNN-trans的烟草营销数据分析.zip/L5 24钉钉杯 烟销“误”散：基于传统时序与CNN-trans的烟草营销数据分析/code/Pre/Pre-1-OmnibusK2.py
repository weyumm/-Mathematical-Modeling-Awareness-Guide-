﻿import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns

# 设置字体以显示中文
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 尝试读取Excel文件
try:
    # 文件路径
    file_path = r"A1.xlsx"
    # 读取数据
    data = pd.read_excel(file_path)
    
    # 检查销量（箱）列是否存在
    if '销量（箱）' in data.columns:
        # 提取销量（箱）列数据
        sales_data = data['销量（箱）']
        
        # 正态性检验
        k2, p = stats.normaltest(sales_data)
        
        # 准备输出结果
        normal_test_result = {
            '检验统计量': k2,
            'p值': p
        }
        
        # 创建画布
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
        
        # 绘制直方图和密度曲线
        sns.histplot(sales_data, kde=True, ax=ax1)
        ax1.set_title('销量（箱）分布图')
        ax1.set_xlabel('销量（箱）')
        ax1.set_ylabel('频率')
        
        # 绘制 Q-Q 图
        stats.probplot(sales_data, plot=ax2, fit=True)
        ax2.set_title('Q-Q 图')
        
        # 调整子图之间的间距
        plt.tight_layout()
        
        # 显示图表
        plt.show()
        
        # 返回正态性检验结果
        print(normal_test_result)
    else:
        "销量（箱）列在数据中不存在。"
except Exception as e:
    print(str(e))
