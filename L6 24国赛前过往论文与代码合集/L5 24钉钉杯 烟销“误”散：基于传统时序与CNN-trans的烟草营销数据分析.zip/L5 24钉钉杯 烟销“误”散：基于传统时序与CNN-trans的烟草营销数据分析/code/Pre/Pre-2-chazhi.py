﻿import pandas as pd
import matplotlib.pyplot as plt

# 读取Excel文件
file_path = r"A3_step3.xlsx"
data = pd.read_excel(file_path)

# 插值数据的月份
interpolated_months = [201502,201504,201612,202012,202112]

# 创建一个新列来标记是否为插值数据
data['is_interpolated'] = data['月份'].isin(interpolated_months)

# 筛选201401到202212的月份数据
filtered_data = data[(data['月份'] >= 201401) & (data['月份'] <= 202212)]

# 将月份转换为连续数值
filtered_data['month_index'] = range(1, len(filtered_data) + 1)

# 筛选出月份末尾为06的记录
june_data = filtered_data[filtered_data['月份'] % 100 == 6].copy()

# 为这些月份生成对应的年份标签
june_data.loc[:, 'year_label'] = (june_data['月份'] // 100).astype(str)

# 创建图形和轴
plt.figure(figsize=(14, 7),dpi=200)
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False

# 绘制所有数据的折线图
plt.plot(filtered_data['month_index'], filtered_data['销量（箱）'], 
         label='原始数据', color='royalblue', linestyle='-', marker='o', markersize=6)

# 标红插值数据点
interpolated_data = filtered_data[filtered_data['is_interpolated']]
plt.scatter(interpolated_data['month_index'], interpolated_data['销量（箱）'], 
            color='crimson', label='插值数据', edgecolor='black', s=100)

# 添加竖线分隔年份
years = range(2015, 2023)
for year in years:
    start_index = filtered_data[filtered_data['月份'] == year * 100 + 1]['month_index'].values[0]
    plt.axvline(x=start_index - 0.5, color='gray', linestyle='--', linewidth=1)

# 添加x轴刻度标签，只显示月份末尾为06的
plt.xticks(june_data['month_index'], june_data['year_label'], rotation=0, fontsize=10)

# 添加图例
plt.legend(loc='upper left')

# 添加标题和标签
plt.title('A(硬蓝爱你)销量数据及插值点', fontsize=16, fontweight='bold')
plt.xlabel('年份', fontsize=14)
plt.ylabel('销量（箱）', fontsize=14)

# 添加网格线
plt.grid(True, linestyle='--', alpha=0.7)

# 显示图形
plt.tight_layout()
plt.show()