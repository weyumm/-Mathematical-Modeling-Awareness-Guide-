import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import os

# 定义现有数据
data = {
    '月份': ['202301', '202302', '202303'],
    '样品代码': ['33010603', '33010603', '33010603'],
    '名称': ['A(新版)', 'A(新版)', 'A(新版)'],
    '销量（箱）': [749.004, 191.048, 298.564],
    '金额（元）': [23024382.96, 5872815.52, 9177857.36],
    '单价（元）': [30740, 30740, 30740],
    '年份': [2023, 2023, 2023],
    '月份_数字': [1, 2, 3],
    '累计销量': [20701.708, 20892.756, 21191.32],
    '是否为春节所在月': [1, 0, 0],
    '月份的天数': [31, 28, 31],
    '该月平均每天销量（箱）': [24.16141935, 6.823142857, 9.631096774],
    '该月平均每天金额（元）': [742722.031, 209743.4114, 296059.9148]
}

# 将数据转换为 DataFrame
df = pd.DataFrame(data)

def r2_keras(y_true, y_pred):
    SS_res = tf.reduce_sum(tf.square(y_true - y_pred))
    SS_tot = tf.reduce_sum(tf.square(y_true - tf.reduce_mean(y_true)))
    return (1 - SS_res / (SS_tot + tf.keras.backend.epsilon()))

# 预处理数据
def preprocess_data(df):
    scaler = MinMaxScaler()
    scaled_df = df.copy()
    scaled_df[['单价（元）', '销量（箱）', '金额（元）', '年份', '月份_数字', '月份的天数', '该月平均每天销量（箱）', '该月平均每天金额（元）']] = scaler.fit_transform(df[['单价（元）', '销量（箱）', '金额（元）', '年份', '月份_数字', '月份的天数', '该月平均每天销量（箱）', '该月平均每天金额（元）']])
    return scaled_df, scaler

# 加载并预处理数据
df_scaled, scaler = preprocess_data(df)

# 构建数据窗口
def create_prediction_window(data, window_size):
    return np.array([data.iloc[i:i+window_size][['单价（元）', '销量（箱）', '金额（元）', '年份', '月份_数字', '是否为春节所在月', '月份的天数', '该月平均每天销量（箱）', '该月平均每天金额（元）']].values for i in range(len(data) - window_size + 1)])

# 反归一化预测结果
def inverse_transform_predictions(predictions, scaler):
    dummy_data = np.zeros((predictions.shape[0], len(scaler.min_)))
    dummy_data[:, scaler.feature_names_in_.tolist().index('销量（箱）')] = predictions.flatten()
    rescaled_data = scaler.inverse_transform(dummy_data)
    return rescaled_data[:, scaler.feature_names_in_.tolist().index('销量（箱）')]

# 计算新数据
def calculate_new_data(df, prediction, next_month):
    new_row = {}
    new_row['月份'] = next_month
    new_row['样品代码'] = '33010603'
    new_row['名称'] = 'A(新版)'
    new_row['单价（元）'] = 30740
    new_row['销量（箱）'] = prediction
    new_row['金额（元）'] = new_row['单价（元）'] * new_row['销量（箱）']
    new_row['年份'] = int(new_row['月份'][:4])
    new_row['月份_数字'] = int(new_row['月份'][4:])
    new_row['累计销量'] = df['累计销量'].iloc[-1] + new_row['销量（箱）']
    new_row['是否为春节所在月'] = 0
    if new_row['月份_数字'] in [4, 6, 9, 11]:
        new_row['月份的天数'] = 30
    elif new_row['月份_数字'] in [1, 3, 5, 7, 8, 10, 12]:
        new_row['月份的天数'] = 31
    else:
        if (new_row['年份'] % 4 == 0 and new_row['年份'] % 100 != 0) or (new_row['年份'] % 400 == 0):
            new_row['月份的天数'] = 29
        else:
            new_row['月份的天数'] = 28
    new_row['该月平均每天销量（箱）'] = new_row['销量（箱）'] / new_row['月份的天数']
    new_row['该月平均每天金额（元）'] = new_row['金额（元）'] / new_row['月份的天数']
    return new_row

# 构建加载模型的函数
def load_model_for_current_window_size(window_size):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    model_filename = f'cnn_trans_model{window_size}.keras'
    model_path = os.path.join(current_dir, 'cnn_trans_models', model_filename)
    return tf.keras.models.load_model(model_path, custom_objects={'r2_keras': r2_keras})

# 进行迭代预测
months_to_predict = int(input("请输入你想预测多少个月的数值？（起始月份202404）"))
current_df_scaled = df_scaled.copy()
next_month = 202304

for _ in range(months_to_predict):
    # 根据当前数据量选择相应的模型
    current_data_length = len(df)
    window_size = min(current_data_length, 12)
    model = load_model_for_current_window_size(window_size)

    # 构建当前窗口
    X = create_prediction_window(current_df_scaled, window_size)
    
    # 确保输入形状匹配
    if X.shape[0] < 1:
        print("形状不匹配")
        break
    
    # 进行预测
    predictions = model.predict(X)
    
    # 反归一化预测结果
    predictions_rescaled = inverse_transform_predictions(predictions, scaler)
    
    # 获取最后一个预测值
    last_prediction = predictions_rescaled[-1]
    
    # 计算下一个月份
    next_month_str = str(next_month)
    next_year = int(next_month_str[:4])
    next_month_num = int(next_month_str[4:])
    if next_month_num == 12:
        next_month = (next_year + 1) * 100 + 1
    else:
        next_month = next_year * 100 + (next_month_num + 1)
    
    # 计算新数据并添加到 DataFrame
    new_row = calculate_new_data(df, last_prediction, next_month_str)
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    
    # 更新缩放数据集
    current_df_scaled, _ = preprocess_data(df)


# 确保 Matplotlib 支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置中文字体
plt.rcParams['axes.unicode_minus'] = False  # 解决坐标轴负数显示问题

# 绘制销量随月份变化的折线图
plt.figure(figsize=(10, 6))
plt.plot(df['月份'], df['销量（箱）'], label='原始数据', color='blue')
plt.plot(df['月份'][3:], df['销量（箱）'][3:], label='预测数据', color='red')
plt.xlabel('月份')
plt.ylabel('销量（箱）')
plt.title('销量随月份变化图')
plt.legend()
plt.show()

print("预测的具体数值：")
for i in range(3, len(df)):
    print(f"月份: {df['月份'][i]}, 预测销量（箱）: {df['销量（箱）'][i]:.2f}")


# 预测的具体数值
predicted_data = {
    '标蓝': [
        ('201101', 279.228), ('201102', 75.952), ('201103', 107.432), ('201104', 101.932), ('201105', 101.512), 
        ('201106', 90.208), ('201107', 138.236), ('201108', 134.42), ('201109', 130.016), ('201110', 75.592), 
        ('201111', 107.164), ('201112', 50.62), ('201201', 386.992), ('201202', 71.028), ('201203', 125.296), 
        ('201204', 167.92), ('201205', 133.48), ('201206', 105.448), ('201207', 124.06), ('201208', 151.368), 
        ('201209', 135.784), ('201210', 135.024), ('201211', 116.36), ('201212', 36.924), ('201301', 549.096), 
        ('201302', 140.196), ('201303', 216.868), ('201304', 103.676), ('201305', 129.736), ('201306', 123.028), 
        ('201307', 208.168), ('201308', 185.712), ('201309', 156.112), ('201310', 173.348), ('201311', 167.068), 
        ('201312', 0.256), ('201401', 805.128), ('201402', 138.416), ('201403', 171.32), ('201404', 257.936), 
        ('201405', 332.34), ('201406', 268.36), ('201407', 242.948), ('201408', 261.312), ('201409', 261.58), 
        ('201410', 213.84), ('201411', 253.936), ('201412', 197.156), ('201501', 488.992), ('201502', 332.236), 
        ('201503', 293.668), ('201504', 275.2), ('201505', 252.136), ('201506', 305.976), ('201507', 254.268), 
        ('201508', 231.152), ('201509', 267.072), ('201510', 206.984), ('201511', 216.06), ('201512', 234.024), 
        ('201601', 468.52), ('201602', 228.416), ('201603', 238.952), ('201604', 230.04), ('201605', 234.004), 
        ('201606', 254.872), ('201607', 252.22), ('201608', 268.856), ('201609', 276.38), ('201610', 174.856), 
        ('201611', 221.116), ('201612', 175.732), ('201701', 560.72), ('201702', 161.548), ('201703', 200.824), 
        ('201704', 188.044), ('201705', 210.376), ('201706', 211.72), ('201707', 206.48), ('201708', 256.912), 
        ('201709', 279.044), ('201710', 234.224), ('201711', 217.932), ('201712', 89.952), ('201801', 586.812), 
        ('201802', 245.788), ('201803', 167.408), ('201804', 154.384), ('201805', 204.804), ('201806', 222.232), 
        ('201807', 255.336), ('201808', 276.9)],
    '标绿': [('202301', 749.004), ('202302', 191.048), ('202303', 298.564)],
    '标红':  list(zip(df['月份'][3:], df['销量（箱）'][3:]))
}

# 创建图表
plt.figure(figsize=(12, 8))

# 绘制原始数据（标蓝）
original_data = predicted_data['标蓝']
months, values = zip(*original_data)
plt.plot(months, values, marker='o', linestyle='-', color='blue', label='原始数据')

# 绘制预测数据（标绿）
predicted_green = predicted_data['标绿']
months, values = zip(*predicted_green)
plt.plot(months, values, marker='o', linestyle='-', color='green', label='给定数据')

# 绘制预测数据（标红）
predicted_red = predicted_data['标红']
months, values = zip(*predicted_red)
plt.plot(months, values, marker='o', linestyle='-', color='red', label='预测数据')

# 绘制连接线
for i in range(len(predicted_red) - 1):
    plt.plot([predicted_red[i][0], predicted_red[i+1][0]], [predicted_red[i][1], predicted_red[i+1][1]], color='red')

# 设置图表标题和标签
plt.title('cnn-trans预测销量随月份变化图')
plt.xlabel('年份')
plt.ylabel('销量（箱）')

# 设置x轴标签
ticks1 = [item[0] for item in predicted_data['标蓝']]
labels1 = [f"{tick[:4]}" if tick.endswith('06') else "" for tick in ticks1]
ticks2 = [item[0] for item in predicted_data['标绿']]
labels2 = [f"{tick[:4]}" if tick.endswith('06') else "" for tick in ticks2]
ticks3 = [item[0] for item in predicted_data['标红']]
labels3 = [f"{tick[:4]}" if tick.endswith('06') else "" for tick in ticks3]

plt.xticks(ticks=ticks1+ticks2+ticks3, labels=labels1+labels2+labels3)

# 添加图例
plt.legend()

# 自动调整布局
plt.tight_layout()

# 显示图表
plt.show()
