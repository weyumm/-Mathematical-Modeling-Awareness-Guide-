﻿import pandas as pd
from scipy.stats import shapiro, levene, kruskal
import matplotlib.pyplot as plt
import seaborn as sns
from scikit_posthocs import posthoc_dunn

# 加载数据
data = pd.read_excel('预测用表.xlsx')

# 将六位整数的月份列转换为日期时间格式
data['月份'] = pd.to_datetime(data['月份'], format='%Y%m')

# 提取年份
data['年份'] = data['月份'].dt.year

# 打印数据头部以确认
print(data.head())

# 正态性检验
normality_results = {}
for year in data['年份'].unique():
    group_data = data[data['年份'] == year]['金额（元）']
    stat, p_value = shapiro(group_data)
    normality_results[year] = p_value

print("\n正态性检验结果 (p-value):")
for year, p_value in normality_results.items():
    print(f"{year}: {p_value}")

# 方差齐性检验
grouped_data = [data[data['年份'] == year]['金额（元）'] for year in data['年份'].unique()]
stat, p_value = levene(*grouped_data)
print(f"\n方差齐性检验结果 (p-value): {p_value}")

# Kruskal-Wallis H 检验
h_stat, p_value = kruskal(*grouped_data)
print(f"\nKruskal-Wallis H 检验结果:")
print(f"H statistic: {h_stat}")
print(f"p-value: {p_value}")

# 画 Dunn's Test 的热力图
# 计算 Dunn's Test
dunn_test = posthoc_dunn(data, val_col='金额（元）', group_col='年份')

# 绘制 Dunn's Test 结果的热力图
plt.figure(figsize=(10, 8))
sns.heatmap(dunn_test, annot=True, cmap='plasma', fmt='.4f', linewidths=0.5, vmin=0, vmax=1)
plt.title("A5金额：Dunn's Test p-values Heatmap")
plt.show()
