﻿import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from pmdarima import auto_arima
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from prophet import Prophet
import matplotlib.pyplot as plt

# 设置字体以显示中文
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 加载数据时指定日期列解析
data_A1 = pd.read_excel('A4_step3.xlsx')
data_A2 = pd.read_excel('A3_step3.xlsx')

# 将六位整数的月份列转换为日期时间格式
data_A1['月份'] = pd.to_datetime(data_A1['月份'], format='%Y%m')
data_A2['月份'] = pd.to_datetime(data_A2['月份'], format='%Y%m')

# 数据归一化
def normalize_data(data):
    if isinstance(data, pd.DataFrame):
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data['金额（元）'].values.reshape(-1, 1))
        return scaler, data_scaled
    elif isinstance(data, np.ndarray):
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data.reshape(-1, 1))
        return scaler, data_scaled
    else:
        raise TypeError("数据类型不支持，必须是DataFrame或NumPy数组")

# 训练并预测使用 SARIMA 模型
def train_and_predict_sarima(data, steps=12):
    arima_model = auto_arima(data['金额（元）'], start_p=1, max_p=3, start_q=1, max_q=3,
                             start_P=0, max_P=2, start_Q=0, max_Q=2,
                             seasonal=True, m=12)
    order = arima_model.order
    seasonal_order = arima_model.seasonal_order
    
    sarima_model = SARIMAX(data['金额（元）'], order=order, seasonal_order=seasonal_order)
    sarima_model_fit = sarima_model.fit(disp=False)
    
    forecast = sarima_model_fit.get_forecast(steps=steps).predicted_mean.values
    return forecast, sarima_model_fit

# 计算评估指标：MSE, MAE, RMSE, R^2, MAPE
def calculate_metrics(y_true, y_pred):
    min_len = min(len(y_true), len(y_pred))
    y_true = y_true[-min_len:]
    y_pred = y_pred[-min_len:]
    
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    return mse, mae, rmse, r2, mape

# 计算残差描述性统计
def print_residuals_statistics(residuals, model_name):
    print(f"{model_name} 模型残差描述性统计:")
    print(f"均值: {np.mean(residuals):.2f}")
    print(f"标准差: {np.std(residuals):.2f}")
    print(f"最小值: {np.min(residuals):.2f}")
    print(f"最大值: {np.max(residuals):.2f}")
    print(f"25th 百分位: {np.percentile(residuals, 25):.2f}")
    print(f"50th 百分位 (中位数): {np.percentile(residuals, 50):.2f}")
    print(f"75th 百分位: {np.percentile(residuals, 75):.2f}")
    print()

# 主函数
def main(steps=12):
    
    # SARIMA模型预测 A1
    forecast_sarima_A1, sarima_model_A1 = train_and_predict_sarima(data_A1, steps=steps)
    mse_sarima_A1, mae_sarima_A1, rmse_sarima_A1, r2_sarima_A1, mape_sarima_A1 = calculate_metrics(data_A1['金额（元）'].values[-steps:], forecast_sarima_A1)
    
    # Prophet模型预测 A1
    prophet_model_A1 = Prophet(daily_seasonality=False, yearly_seasonality=True, weekly_seasonality=True)
    df_A1 = pd.DataFrame({'ds': data_A1['月份'], 'y': data_A1['金额（元）']})
    prophet_model_A1.fit(df_A1)
    future_A1 = prophet_model_A1.make_future_dataframe(periods=steps, freq='M')
    forecast_prophet_A1 = prophet_model_A1.predict(future_A1)
    forecast_prophet_A1 = forecast_prophet_A1[-steps:]['yhat'].values
    mse_prophet_A1, mae_prophet_A1, rmse_prophet_A1, r2_prophet_A1, mape_prophet_A1 = calculate_metrics(data_A1['金额（元）'].values[-steps:], forecast_prophet_A1)
    
    # 计算 SARIMA 和 Prophet 的加权平均作为最终预测结果
    alpha = 0.5  # SARIMA 权重
    forecast_combined_A1 = alpha * forecast_sarima_A1 + (1 - alpha) * forecast_prophet_A1
    mse_combined_A1, mae_combined_A1, rmse_combined_A1, r2_combined_A1, mape_combined_A1 = calculate_metrics(data_A1['金额（元）'].values[-steps:], forecast_combined_A1)
    
    # 打印预测结果和评估指标
    print("SARIMA 模型评估指标:")
    print(f"预测销量:\n{forecast_sarima_A1}\n")
    print(f"评估指标(MSE, MAE, RMSE, R^2, MAPE): {mse_sarima_A1:.2f}, {mae_sarima_A1:.2f}, {rmse_sarima_A1:.2f}, {r2_sarima_A1:.4f}, {mape_sarima_A1:.2f}%\n")

    print("Prophet 模型评估指标:")
    print(f"预测销量:\n{forecast_prophet_A1}\n")
    print(f"评估指标(MSE, MAE, RMSE, R^2, MAPE): {mse_prophet_A1:.2f}, {mae_prophet_A1:.2f}, {rmse_prophet_A1:.2f}, {r2_prophet_A1:.4f}, {mape_prophet_A1:.2f}%\n")

    print("融合模型评估指标:")
    print(f"预测销量:\n{forecast_combined_A1}\n")
    print(f"评估指标(MSE, MAE, RMSE, R^2, MAPE): {mse_combined_A1:.2f}, {mae_combined_A1:.2f}, {rmse_combined_A1:.2f}, {r2_combined_A1:.4f}, {mape_combined_A1:.2f}%\n")
    
    # 打印残差描述性统计
    residual_sarima = data_A1['金额（元）'].values[-steps:] - forecast_sarima_A1
    residual_prophet = data_A1['金额（元）'].values[-steps:] - forecast_prophet_A1

    print_residuals_statistics(residual_sarima, 'SARIMA')
    print_residuals_statistics(residual_prophet, 'Prophet')
    
    # 绘制时间序列历史数据和预测结果图表
    plot_forecasts(data_A1, forecast_sarima_A1, forecast_prophet_A1, forecast_combined_A1, steps)
    
    # 绘制预测残差图
    plot_residuals(data_A1, forecast_sarima_A1, forecast_prophet_A1, steps)

# 绘制时间序列历史数据和预测结果图表
def plot_forecasts(data, forecast_sarima, forecast_prophet, forecast_combined, steps):
    plt.figure(figsize=(14, 7))
    
    # 绘制历史销量数据
    plt.plot(data['月份'], data['金额（元）'], label='历史金额', color='blue')
    
    # 绘制 SARIMA 预测结果
    future_dates_sarima = pd.date_range(start=data['月份'].iloc[-1] + pd.DateOffset(months=1), periods=len(forecast_sarima), freq='M')
    plt.plot(future_dates_sarima, forecast_sarima, label='SARIMA预测', color='purple', linestyle=':')
    
    # 绘制 Prophet 预测结果
    future_dates_prophet = pd.date_range(start=data['月份'].iloc[-1] + pd.DateOffset(months=1), periods=len(forecast_prophet), freq='M')
    plt.plot(future_dates_prophet, forecast_prophet, label='Prophet预测', color='green', linestyle='--')
    
    # 绘制融合模型预测结果
    future_dates_combined = pd.date_range(start=data['月份'].iloc[-1] + pd.DateOffset(months=1), periods=len(forecast_combined), freq='M')
    plt.plot(future_dates_combined, forecast_combined, label='融合模型预测', color='red', linestyle='-')
    
    plt.title('A4 品牌金额预测')
    plt.xlabel('日期')
    plt.ylabel('金额（元）')
    plt.legend()
    plt.grid(True)
    plt.show()

# 绘制预测残差图
def plot_residuals(data, forecast_sarima, forecast_prophet, steps):
    residual_sarima = data['金额（元）'].values[-steps:] - forecast_sarima
    residual_prophet = data['金额（元）'].values[-steps:] - forecast_prophet
    
    plt.figure(figsize=(14, 7))
    
    # 绘制 SARIMA 残差图
    plt.subplot(1, 2, 1)
    plt.plot(data['月份'].iloc[-steps:], residual_sarima, label='SARIMA 残差', color='purple')
    plt.title('SARIMA 模型残差')
    plt.xlabel('日期')
    plt.ylabel('残差')
    plt.legend()
    plt.grid(True)
    
    # 绘制 Prophet 残差图
    plt.subplot(1, 2, 2)
    plt.plot(data['月份'].iloc[-steps:], residual_prophet, label='Prophet 残差', color='green')
    plt.title('Prophet 模型残差')
    plt.xlabel('日期')
    plt.ylabel('残差')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.show()

# 主函数调用
if __name__ == "__main__":
    steps = 10  # 可以修改预测步数
    main(steps)