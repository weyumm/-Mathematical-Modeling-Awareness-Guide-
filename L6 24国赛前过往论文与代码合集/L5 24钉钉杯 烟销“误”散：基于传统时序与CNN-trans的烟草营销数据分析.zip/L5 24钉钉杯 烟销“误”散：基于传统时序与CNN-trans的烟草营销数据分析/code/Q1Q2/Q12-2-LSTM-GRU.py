﻿import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# 1. 环境清理
import gc
gc.collect()

# 2. 导入数据，单序列
data = pd.read_excel("A4_step3.xlsx", usecols=[4]).dropna().values.flatten()

# 原始数据绘图
plt.figure()
plt.plot(data, '-s', color=[0, 0, 1], linewidth=1, markersize=5, markerfacecolor=[0, 0, 1])
plt.legend(['原始数据'], loc='upper left', prop={'family': 'SimSun'})
plt.xlabel('样本', fontsize=12, family='SimSun')
plt.ylabel('数值', fontsize=12, family='SimSun')
plt.show()

# 3. 定义LSTM结构参数
num_features = 12  # 输入节点(参考量)
num_responses = 1  # 输出节点
num_hidden_units = 500  # 隐含层神经元节点数

# 4. 数据处理
nn = len(data) - num_features - 10  # 训练数据集大小
num_time_steps_train = nn

# 标准化数据
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data.reshape(-1, 1)).flatten()

# 构建训练集和测试集
X, y = [], []
for i in range(num_time_steps_train):
    X.append(data_scaled[i:i+num_features])
    y.append(data_scaled[i+num_features])
X_train, y_train = np.array(X), np.array(y)

X_test, y_test = [], []
for i in range(num_time_steps_train, len(data_scaled) - num_features):
    X_test.append(data_scaled[i:i+num_features])
    y_test.append(data_scaled[i+num_features])
X_test, y_test = np.array(X_test), np.array(y_test)

# 5. 构建 LSTM网络
model = Sequential()
model.add(LSTM(num_hidden_units, return_sequences=False, input_shape=(num_features, 1)))
model.add(Dropout(0.2))
model.add(Dense(num_responses))

model.compile(optimizer='adam', loss='mse')

# 6. 训练LSTM网络
history = model.fit(X_train.reshape(X_train.shape[0], X_train.shape[1], 1), y_train, epochs=50, batch_size=32, validation_split=0.2, verbose=1)

# 7. 建立训练模型
y_pred_train = model.predict(X_train.reshape(X_train.shape[0], X_train.shape[1], 1))
y_pred_test = model.predict(X_test.reshape(X_test.shape[0], X_test.shape[1], 1))

# 反标准化预测结果
y_pred_train = scaler.inverse_transform(y_pred_train)
y_train = scaler.inverse_transform(y_train.reshape(-1, 1))

y_pred_test = scaler.inverse_transform(y_pred_test)
y_test = scaler.inverse_transform(y_test.reshape(-1, 1))

# 8. 评价指标
# 均方根误差
error1 = np.sqrt(mean_squared_error(y_train, y_pred_train))
error2 = np.sqrt(mean_squared_error(y_test, y_pred_test))
print(f'训练集数据的RMSE为：{error1}')
print(f'验证集数据的RMSE为：{error2}')

# MAE
mae1 = mean_absolute_error(y_train, y_pred_train)
mae2 = mean_absolute_error(y_test, y_pred_test)
print(f'训练集数据的MAE为：{mae1}')
print(f'验证集数据的MAE为：{mae2}')

# MAPE
maep1 = np.mean(np.abs((y_pred_train - y_train) / y_train))
maep2 = np.mean(np.abs((y_pred_test - y_test) / y_test))
print(f'训练集数据的MAPE为：{maep1}')
print(f'验证集数据的MAPE为：{maep2}')

# Residuals and descriptive statistics
residuals_train = y_train.flatten() - y_pred_train.flatten()
residuals_test = y_test.flatten() - y_pred_test.flatten()

print(f'训练集残差的均值：{np.mean(residuals_train)}')
print(f'训练集残差的标准差：{np.std(residuals_train)}')
print(f'测试集残差的均值：{np.mean(residuals_test)}')
print(f'测试集残差的标准差：{np.std(residuals_test)}')

# Compute and print R^2
r2_train = r2_score(y_train, y_pred_train)
r2_test = r2_score(y_test, y_pred_test)
print(f'训练集数据的R^2为：{r2_train}')
print(f'验证集数据的R^2为：{r2_test}')

# 9. 绘图
plt.figure()
plt.subplot(1, 2, 1)
plt.plot(y_pred_test, '-s', color=[0, 0, 1], linewidth=1, markersize=5, markerfacecolor=[0, 0, 1])
plt.plot(y_test, '-o', color=[0, 0, 0], linewidth=0.8, markersize=4, markerfacecolor=[0, 0, 0])
plt.legend(['LSTM预测测试数据', '实际分析数据'], loc='best')
plt.title('LSTM模型预测结果及真实值', fontsize=12)
plt.xlabel('样本', fontsize=12)
plt.ylabel('数值', fontsize=12)
plt.xlim([0, len(y_test)])

plt.subplot(1, 2, 2)
plt.bar(range(len(y_test)), (y_pred_test.flatten() - y_test.flatten()) / y_test.flatten())
plt.legend(['LSTM模型测试集相对误差'], loc='upper right')
plt.title('LSTM模型测试集相对误差', fontsize=12)
plt.ylabel('误差', fontsize=12)
plt.xlabel('样本', fontsize=12)
plt.xlim([0, len(y_test)])
plt.tight_layout()

plt.show()

# 10. 循环预测
pre_num = 10  # 要预测多少期
temp_data = data_scaled.copy()
predict_record = []

for i in range(pre_num):
    input_seq = temp_data[-num_features:].reshape(1, num_features, 1)  # 确保输入形状为 (1, num_features, 1)
    temp_result = model.predict(input_seq)  # 预测
    temp_result = scaler.inverse_transform(temp_result)  # 反标准化
    predict_record.append(temp_result[0, 0])  # 保存预测结果
    temp_data = np.append(temp_data, scaler.transform(temp_result).flatten())  # 更新输入数据

predict_record = np.array(predict_record)

plt.figure()
plt.plot(range(len(data)), data, '-s', color=[1, 0, 0], linewidth=1, markersize=5, markerfacecolor=[1, 0, 0])
plt.plot(range(len(data), len(data) + pre_num), predict_record, '-o', color=[0.6, 0.6, 0.6], linewidth=0.8, markersize=4, markerfacecolor=[0.6, 0.6, 0.6])
plt.legend(['原始数据', 'LSTM预测结果'], loc='upper left')
plt.title('LSTM模型预测结果', fontsize=12)
plt.xlabel('样本', fontsize=12)
plt.ylabel('数值', fontsize=12)
plt.show()

# Print prediction data
print('预测数据:')
print(predict_record)
