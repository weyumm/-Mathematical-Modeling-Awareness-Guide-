Pre(数据预处理代码)：
0-notebook-代码草稿
1-Omnibus K2检验
2-多项式回归插值
3-数据处理：A1-A5处理的完整代码

Q1Q2：
0-Ai_step3-Pre处理后的所有数据
1-基于Prophet修正的SARIMA模型
2-LSTM+GRU融合模型

Q3：
1-时间-销量-金额相关性检验
2-CNN-Transformer模型调用代码
